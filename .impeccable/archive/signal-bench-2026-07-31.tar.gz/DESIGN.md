---
name: Playerinyo
description: A dark hardware-bench interface for operating, maintaining, and playing an owned local music collection.
colors:
  safety-orange: "#E85D22"
  safety-orange-hot: "#FF7834"
  amber-display: "#FFAD3D"
  status-green: "#9AAE70"
  chassis-black: "#0A0B0A"
  faceplate: "#171917"
  raised-metal: "#252620"
  screen-black: "#100E09"
  screen-deep: "#070705"
  warm-ink: "#E4DDCE"
  muted-ink: "#A9A291"
  disabled-ink: "#706D65"
  chassis-rule: "#4A4A42"
  putty-key: "#B9B09F"
  putty-highlight: "#D4CBBB"
  putty-shadow: "#777166"
  danger: "#F05D5E"
  control-ink: "#17100B"
typography:
  display:
    fontFamily: "'Bench Sans', 'Arial Narrow', sans-serif"
    fontSize: "58px"
    fontWeight: 650
    lineHeight: 0.95
    letterSpacing: "0.04em"
    fontVariation: "'wdth' 92, 'wght' 650"
  page-title:
    fontFamily: "'Bench Sans', 'Arial Narrow', sans-serif"
    fontSize: "38px"
    fontWeight: 650
    lineHeight: 1
    letterSpacing: "0.04em"
  section:
    fontFamily: "'Bench Sans', 'Arial Narrow', sans-serif"
    fontSize: "24px"
    fontWeight: 650
    letterSpacing: "0.06em"
  title:
    fontFamily: "system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif"
    fontSize: "14px"
    fontWeight: 780
  body:
    fontFamily: "system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif"
    fontSize: "13px"
    fontWeight: 500
    lineHeight: 1.55
  data:
    fontFamily: "ui-monospace, 'SFMono-Regular', Consolas, monospace"
    fontSize: "10px"
    fontWeight: 700
    letterSpacing: "0.08em"
  label:
    fontFamily: "ui-monospace, 'SFMono-Regular', Consolas, monospace"
    fontSize: "9px"
    fontWeight: 700
    letterSpacing: "0.12em"
rounded:
  square: "0px"
  indicator: "2px"
  compact: "3px"
  artwork: "4px"
  control: "5px"
  keycap: "6px"
  module: "7px"
  chassis: "8px"
  circle: "50%"
spacing:
  shell-gap: "9px"
  control-gap: "7px"
  card-gap: "16px"
  card-inset: "10px"
  module-inset: "14px"
  panel-inset: "24px"
  faceplate-inset: "32px"
components:
  safety-key:
    backgroundColor: "{colors.safety-orange}"
    textColor: "{colors.control-ink}"
    rounded: "{rounded.keycap}"
    height: "58px"
  putty-key:
    backgroundColor: "{colors.putty-key}"
    textColor: "{colors.control-ink}"
    rounded: "{rounded.keycap}"
    height: "58px"
  amber-readout:
    backgroundColor: "{colors.screen-deep}"
    textColor: "{colors.amber-display}"
    rounded: "{rounded.artwork}"
  album-tray:
    backgroundColor: "{colors.faceplate}"
    textColor: "{colors.warm-ink}"
    rounded: "{rounded.keycap}"
    padding: "{spacing.card-inset}"
  player-chassis:
    backgroundColor: "{colors.faceplate}"
    textColor: "{colors.warm-ink}"
    rounded: "{rounded.chassis}"
    height: "94px"
  modal-faceplate:
    backgroundColor: "{colors.faceplate}"
    textColor: "{colors.warm-ink}"
    rounded: "{rounded.chassis}"
    padding: "{spacing.panel-inset}"
---

# Design System: Playerinyo

## Overview

**Creative North Star: "Signal Bench"**

Playerinyo treats a local music library as an instrument the listener owns and operates. The application shell is a continuous gunmetal bench: playlists sit in a media bay, collection statistics glow in an amber readout, maintenance actions become tactile keys, and playback remains mounted along the lower chassis.

The interface is not a literal skeuomorphic machine. Hardware references communicate hierarchy and operation through faceplates, recesses, key travel, rack screws, and restrained status light. Album artwork remains the broadest source of color.

**Key Characteristics:**

- Matte gunmetal chassis with warm ink, shallow bevels, and visible assembly points.
- Safety orange for decisive actions; amber for data and transport position; green for healthy local status.
- Putty keycaps for direct collection operations and dark recessed fields for input.
- Cover-led album trays and a searchable playlist media bay.
- Persistent, three-zone transport with every listening tool still reachable.

## Color

Safety Orange is the action signal. It marks Home, primary import, Play, focus, selection, and active playback. Amber Display is reserved for telemetry, timing, readouts, and technical playback status. Status Green indicates a healthy local or indexed state. Danger remains separate from both.

Chassis Black, Faceplate, and Raised Metal establish normal depth. Warm Ink and Muted Ink carry content. Putty Key and its highlight/shadow are limited to controls that should read as tactile hardware, never large content surfaces.

**The Signal, Not Wallpaper Rule.** Orange, amber, and green must communicate a state or action. The shell stays neutral.

**The Artwork Owns Color Rule.** Full-spectrum color belongs to album covers, playlist covers, and explicit integration identities.

**The Theme Role Rule.** Runtime theme controls continue to own accent, background, panel, raised panel, border, text, muted text, and danger. Hardware colors extend those semantic roles rather than disabling customization.

## Typography

Bench Sans is the local Anybody variable asset under a direction-specific family name. Its compact uppercase setting labels collection, album, modal, and section identity. System UI handles controls and sustained reading. Monospace is used only where the hardware metaphor has information value: status, counts, timing, keyboard hints, and technical labels.

Display tracking is positive and deliberate, unlike the archived specimen direction. Long prose stays mixed case and compact. Labels may be uppercase but never replace explanatory copy.

## Layout

Desktop uses an assembled shell with a playlist bay, main work faceplate, optional queue or lyrics module, and lower transport chassis. The sidebar remains wide enough for the searchable four-column playlist archive. The main home view starts with one collection faceplate containing identity and an amber telemetry module, followed by a bank of direct operation keys and cover-led shelves.

At 1180px, the sidebar narrows and the collection faceplate stacks. At 900px, navigation becomes a compact upper module, playlists become a horizontally scrolling labeled media strip, closed queue and lyrics modules leave layout flow, and transport wraps without clipping. At 560px, transport becomes three explicit rows and remains horizontally operable where needed.

**The Persistent Transport Rule.** Track identity, primary transport, seek position, queue, lyrics, EQ, Now Playing, mini-player, and volume remain reachable while content changes.

**The Recoverable Bay Rule.** Compact playlist cards retain cover, name, and count. Expanded playlist mode restores a four-column scrolling field rather than only changing width.

**The Direct Operations Rule.** Import, rescan, tag health, downloads, and Settings stay one action from Home.

## Depth

Normal depth comes from a single boundary plus directional inset and offset shadows. A module may be raised, recessed, or flush; it must not combine an ornamental halo with unrelated glass blur. Stable surfaces are opaque.

- Chassis modules use a warm-gray boundary, top highlight, lower inset shadow, and offset black shadow.
- Readouts and text inputs recess with an inner top shadow.
- Keycaps show travel through a lower edge and offset base shadow; pressed state moves toward that base.
- Album trays use quiet elevation so artwork leads.
- Blocking overlays use the deepest offset shadow and a restrained blurred backdrop.
- Artwork blur remains available only inside Now Playing as content ambience.

`no-glass` and performance modes remove nonessential depth while retaining boundaries, contrast, and layout.

## Shapes

The system uses compact industrial radii: 3px indicators, 4px artwork, 5px controls, 6px keycaps and album trays, 7px modules, and 8px chassis plates. Circles are reserved for status lamps and familiar indicators. Play is a rectangular safety key, not a floating circular button.

## Components

### Navigation

Navigation items are shallow dark keys. The active destination becomes a filled orange key with dark content and visible travel. The playlist section is a recessed bay with direct import, create, and expand controls.

### Collection Faceplate

The home faceplate pairs the collection identity with one amber telemetry screen. Four statistics remain buttons and retain focus, hover, and click affordances inside the display.

### Operation Keys

The five collection actions form one key bank. Import is the orange safety key; the remaining actions use putty keycaps. Hover lifts by one pixel, while press moves toward the key base.

### Album Trays

Album cards are semantic articles with separate Play and Open buttons. Artwork is decorative to assistive technology because both controls already name the album. Hover and playing states change the tray boundary rather than masking the cover.

### Track Table

Tracks remain a ruled table for dense scanning. Playing rows gain an amber tint and title. Multi-select, metadata, context actions, missing files, and disc separators retain explicit states.

### Transport

The lower chassis has now-playing identity, transport plus seek, and listening tools. Amber carries time and progress. The Play key uses safety orange; supporting controls remain dark hardware keys. Responsive layouts must allocate enough height for the complete seek row.

### Inputs And Settings

Inputs are recessed dark wells with amber focus. Settings are grouped into collapsible faceplate modules with programmatic labels and a sticky close control. Theme swatches expose their selected state with `aria-pressed`.

### Overlays

Queue, lyrics, downloads, command search, metadata, Auto-Tag, EQ, shortcuts, and Settings use the same faceplate language. Now Playing may use cover-derived ambience but keeps hardware controls and readable lyrics.

## Do And Don't

**Do:**

- Keep every current collection and playback operation reachable.
- Use orange for decisive action, amber for information, and green for healthy status.
- Preserve visible keyboard focus, disabled, loading, error, empty, playing, selected, and drag states.
- Keep covers square, unmasked, and more colorful than the chassis.
- Let responsive layouts recompose modules instead of clipping them.

**Don't:**

- Reintroduce the archived type-specimen grid, oversized editorial typography, or proof-sheet framing.
- Turn stable surfaces into decorative glass or generic rounded cards.
- Use putty across large reading surfaces or amber for ordinary paragraphs.
- Hide dense maintenance tools behind vague labels.
- Nest interactive controls inside another interactive card role.
