const { app, BrowserWindow, ipcMain, dialog, Tray, Menu, nativeImage, globalShortcut, shell, safeStorage } = require('electron');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const { spawn } = require('child_process');
const { pathToFileURL, fileURLToPath } = require('url');
const { parse } = require('csv-parse');
const NodeID3 = require('node-id3');

let fatalExitInProgress = false;
function handleFatalProcessError(kind, error) {
  console.error(`${kind}:`, error);
  if (fatalExitInProgress) return;
  fatalExitInProgress = true;
  const message = error && error.message ? error.message : String(error || 'Unknown error');
  try {
    if (app.isReady()) dialog.showErrorBox('Playerinyo Fatal Error', `Playerinyo must close because of an unrecoverable error.\n\n${message}`);
  } catch (_) { }
  setImmediate(() => {
    try { app.exit(1); }
    catch (_) { process.exit(1); }
  });
}

process.on('uncaughtException', (err) => handleFatalProcessError('Uncaught exception', err));
process.on('unhandledRejection', (reason) => handleFatalProcessError('Unhandled rejection', reason));

// Discord RPC
let DiscordRPC = null;
let discordClient = null;
let discordEnabled = false;
try {
  DiscordRPC = require('discord-rpc');
} catch (e) { console.log('discord-rpc not available:', e.message); }

let discordLastError = null;
async function discordConnect() {
  if (!DiscordRPC) { discordLastError = "discord-rpc module missing (run npm install)"; return; }
  if (discordClient) return;
  discordLastError = null;
  try {
    discordClient = new DiscordRPC.Client({ transport: 'ipc' });
    discordClient.on('ready', () => { discordEnabled = true; discordLastError = null; console.log('Discord RPC connected'); });
    discordClient.on('disconnected', () => { discordEnabled = false; discordClient = null; discordLastError = "Disconnected from Discord"; });
    discordClient.on('error', (err) => { discordEnabled = false; discordLastError = err && err.message ? err.message : String(err); console.log('Discord RPC error:', discordLastError); });
    await discordClient.login({ clientId: '497005876856053760' });
  } catch (e) { console.log('Discord RPC connect failed:', e.message); discordLastError = e.message; discordClient = null; }
}

async function discordSetActivity(title, artist, album, startTime) {
  if (!discordClient || !discordEnabled) return;
  try {
    await discordClient.setActivity({
      details: title || 'Unknown Track',
      state: artist ? 'by ' + artist : 'Unknown Artist',
      largeImageKey: 'music',
      largeImageText: album || '',
      startTimestamp: startTime ? new Date(startTime) : undefined,
      instance: false,
    });
  } catch (e) { console.log('Discord setActivity error:', e); }
}

async function discordClear() {
  if (!discordClient) return true;
  try { await discordClient.clearActivity(); return true; }
  catch (e) {
    discordLastError = e && e.message ? e.message : String(e);
    console.log('Discord clearActivity error:', discordLastError);
    return false;
  }
}

function getLfmSignature(params, sharedSecret) {
  if (!sharedSecret) return null;
  let keys = Object.keys(params).sort();
  let sig = "";
  for (let k of keys) {
    if (k !== 'format') sig += k + params[k];
  }
  sig += sharedSecret;
  return crypto.createHash('md5').update(sig, 'utf8').digest('hex');
}

// We use dynamic import for music-metadata because modern versions are ESM-only,
// but since we are installing version 7, we can use require.
// However, to be safe against versions, dynamic import or require('music-metadata') works.
let mainWindow;
let mm;
let tray = null;
let trayAvailable = false;
let isQuitting = false;
let quitFlushPending = false;
let quitFlushTimer = null;
let pendingCloseAction = '';
let allowWindowClose = false;
let closeFinishInProgress = false;
let backupRestoreInProgress = false;
let activeDataTransactionPromise = null;
let appSettings = { minimizeToTray: false, useNativeTitleBar: false, ytdlCookiesMode: 'none', ytdlCookiesBrowser: 'firefox', ytdlCookiesFile: '' };
let preservedEncryptedSettings = {};
const undecryptableSettingKeys = new Set();
let mprisPlayer = null;
let mprisTrackId = 0;
let mprisTrackKey = '';
let mprisPositionUs = 0;
let mprisPositionUpdatedAt = 0;
let mprisDurationUs = 0;
let mprisStopped = false;
let spotifyTokenCache = { token: '', expiresAt: 0, key: '' };
const metadataCoverCache = new Map();
const downloadSearchCache = new Map();
const downloadSearchInFlight = new Map();
const activeYtdlpDownloads = new Map();
const cancelledYtdlpDownloads = new Set();
const reservedDownloadRequestIds = new Set();
const pendingBackupImports = new Map();
const DOWNLOAD_SEARCH_CACHE_TTL_MS = 10 * 60 * 1000;
const MAX_BACKUP_BYTES = 64 * 1024 * 1024;
const MAX_BACKUP_VALUES = 1000000;
const BACKUP_TOKEN_TTL_MS = 10 * 60 * 1000;
const MAX_IMAGE_BYTES = 12 * 1024 * 1024;
const MAX_IMAGE_CACHE_ENTRIES = 12;
const MAX_CSV_BYTES = 64 * 1024 * 1024;
const MAX_CSV_RECORDS = 250000;
const MAX_AUDIO_IPC_BYTES = 128 * 1024 * 1024;
const MAX_METADATA_EDIT_BYTES = 512 * 1024 * 1024;
const MAX_DOWNLOADED_AUDIO_BYTES = 512 * 1024 * 1024;
const MAX_SCAN_AUDIO_FILES = 250000;
const MAX_LIBRARY_TRACKS = 250000;
const MAX_PLAYLISTS = 10000;
const MAX_PLAYLIST_TRACKS = 250000;
const PLAYLIST_COLORS = new Set(['#E50914', '#FF003D', '#1DB954', '#2196F3', '#A855F7', '#00BCD4', '#FF9800', '#FFFFFF']);
const EXTERNAL_URL_HOSTS = new Set(['www.youtube.com', 'covers.musichoarders.xyz', 'www.last.fm']);
const IMAGE_URL_HOSTS = new Set(['coverartarchive.org', 'archive.org', 'i.scdn.co', 'i.discogs.com', 'i.ytimg.com', 'lastfm.freetls.fastly.net']);
const APP_ENTRY_URL = pathToFileURL(path.join(__dirname, 'index.html')).href;
const SENSITIVE_SETTING_KEYS = ['lastfmApiKey', 'lastfmSharedSecret', 'lastfmSessionKey', 'discogsToken', 'spotifyClientId', 'spotifyClientSecret'];
const SHORTCUT_ACTIONS = new Set(['playpause', 'next', 'prev', 'shuffle', 'loop', 'queue']);
const DEFAULT_GLOBAL_SHORTCUTS = [
  { id: 'playpause', label: 'Play / Pause', action: 'playpause', accelerator: 'MediaPlayPause', enabled: true },
  { id: 'next', label: 'Next Track', action: 'next', accelerator: 'MediaNextTrack', enabled: true },
  { id: 'prev', label: 'Previous Track', action: 'prev', accelerator: 'MediaPreviousTrack', enabled: true },
  { id: 'shuffle', label: 'Toggle Shuffle', action: 'shuffle', accelerator: 'Ctrl+Shift+S', enabled: false },
  { id: 'loop', label: 'Cycle Loop Mode', action: 'loop', accelerator: 'Ctrl+Shift+L', enabled: false },
  { id: 'queue', label: 'Toggle Queue', action: 'queue', accelerator: 'Ctrl+Shift+Q', enabled: false },
];
const APP_NAME = 'Playerinyo';
const APP_ID = 'playerinyo';
const APP_USER_AGENT = `${APP_NAME}/1.0.0`;
const APP_ICON = path.join(__dirname, 'assets', 'icon.png');

app.setName(APP_NAME);
if (process.platform === 'linux') {
  app.commandLine.appendSwitch('class', APP_ID);
  app.commandLine.appendSwitch('name', APP_ID);
  if (typeof app.setDesktopName === 'function') app.setDesktopName(`${APP_ID}.desktop`);
}

const gotSingleInstanceLock = app.requestSingleInstanceLock();
if (!gotSingleInstanceLock) app.quit();

function isTrustedRendererEvent(event) {
  return !!(mainWindow
    && !mainWindow.isDestroyed()
    && event
    && event.sender === mainWindow.webContents
    && event.senderFrame === mainWindow.webContents.mainFrame
    && event.senderFrame.url === APP_ENTRY_URL);
}

function registerIpcHandler(channel, listener) {
  ipcMain.handle(channel, (event, ...args) => {
    if (!isTrustedRendererEvent(event)) throw new Error('Untrusted IPC sender');
    return listener(event, ...args);
  });
}

function registerIpcListener(channel, listener) {
  ipcMain.on(channel, (event, ...args) => {
    if (!isTrustedRendererEvent(event)) return;
    listener(event, ...args);
  });
}

function isSecureStorageAvailable() {
  if (!safeStorage.isEncryptionAvailable()) return false;
  const backend = typeof safeStorage.getSelectedStorageBackend === 'function' ? safeStorage.getSelectedStorageBackend() : '';
  return backend !== 'basic_text';
}

function serializeSettingsForDisk(settings) {
  const next = { ...settings };
  if (!isSecureStorageAvailable()) {
    for (const key of SENSITIVE_SETTING_KEYS) {
      if (preservedEncryptedSettings[key]) next[key] = preservedEncryptedSettings[key];
      else delete next[key];
    }
    return next;
  }
  for (const key of SENSITIVE_SETTING_KEYS) {
    if (typeof next[key] === 'string' && next[key]) {
      next[key] = {
        __secure: 'electron',
        value: safeStorage.encryptString(next[key]).toString('base64'),
      };
      preservedEncryptedSettings[key] = next[key];
      undecryptableSettingKeys.delete(key);
    } else if (undecryptableSettingKeys.has(key) && preservedEncryptedSettings[key]) {
      next[key] = preservedEncryptedSettings[key];
    } else if (!next[key]) {
      delete preservedEncryptedSettings[key];
    }
  }
  return next;
}

function deserializeSettingsFromDisk(settings) {
  const next = { ...settings };
  for (const key of SENSITIVE_SETTING_KEYS) {
    const value = next[key];
    if (value && typeof value === 'object' && value.__secure === 'electron' && typeof value.value === 'string') preservedEncryptedSettings[key] = value;
    if (!isSecureStorageAvailable()) {
      next[key] = '';
      continue;
    }
    if (!value || typeof value !== 'object' || value.__secure !== 'electron' || typeof value.value !== 'string') continue;
    try {
      next[key] = safeStorage.decryptString(Buffer.from(value.value, 'base64'));
      undecryptableSettingKeys.delete(key);
    } catch (e) {
      console.error(`Failed to decrypt setting: ${key}`, e);
      undecryptableSettingKeys.add(key);
      next[key] = '';
    }
  }
  return next;
}

function readJsonFile(filePath, fallback) {
  try {
    if (fs.existsSync(filePath)) return JSON.parse(fs.readFileSync(filePath, 'utf8'));
  } catch (e) { console.error('Failed to read JSON:', filePath, e); }
  return fallback;
}

function readAppDataFile(filePath, fallback, label, validate) {
  if (!fs.existsSync(filePath)) return fallback;
  try {
    const stat = fs.lstatSync(filePath);
    if (!stat.isFile() || stat.isSymbolicLink()) throw new Error('not a regular data file');
    const value = JSON.parse(fs.readFileSync(filePath, 'utf8'));
    if (validate) validate(value);
    return value;
  } catch (e) {
    throw new Error(`Could not load ${label}: ${e.message || e}`);
  }
}

function readJsonFileStrict(filePath, fallback) {
  try {
    const stat = fs.lstatSync(filePath);
    if (!stat.isFile() || stat.isSymbolicLink()) throw new Error('is not a regular data file');
    if (stat.size > MAX_BACKUP_BYTES) throw new Error(`is larger than the ${MAX_BACKUP_BYTES / (1024 * 1024)} MB backup limit`);
    return JSON.parse(fs.readFileSync(filePath, 'utf8'));
  } catch (e) {
    if (e && e.code === 'ENOENT') return fallback;
    throw new Error(`Could not read ${path.basename(filePath)} for backup: ${e.message || e}`);
  }
}

const fileWriteQueues = new Map();

async function writeTextFileAtomic(filePath, text) {
  const tmpPath = path.join(path.dirname(filePath), `.${path.basename(filePath)}.${process.pid}.${Date.now()}.${Math.random().toString(16).slice(2)}.tmp`);
  try {
    await fs.promises.writeFile(tmpPath, text, { encoding: 'utf8', mode: 0o600 });
    await fs.promises.rename(tmpPath, filePath);
  } catch (e) {
    try { await fs.promises.unlink(tmpPath); } catch (_) { }
    throw e;
  }
}

function queueTextFileWrite(filePath, text) {
  const previous = fileWriteQueues.get(filePath) || Promise.resolve();
  const next = previous.catch(() => { }).then(() => writeTextFileAtomic(filePath, text));
  fileWriteQueues.set(filePath, next);
  const cleanup = () => { if (fileWriteQueues.get(filePath) === next) fileWriteQueues.delete(filePath); };
  next.then(cleanup, cleanup);
  return next;
}

function queueJsonWrite(filePath, data) {
  return queueTextFileWrite(filePath, JSON.stringify(data));
}

async function drainFileWriteQueues() {
  let firstError = null;
  while (fileWriteQueues.size) {
    const pending = Array.from(fileWriteQueues.values());
    const results = await Promise.allSettled(pending);
    for (const result of results) {
      if (result.status === 'rejected' && !firstError) firstError = result.reason;
    }
  }
  if (firstError) throw firstError;
}

async function waitForPendingDataWrites(timeoutMs) {
  const work = (async () => {
    while (activeDataTransactionPromise) await activeDataTransactionPromise;
    await drainFileWriteQueues();
    while (activeDataTransactionPromise) await activeDataTransactionPromise;
  })();
  if (!timeoutMs) return work;
  let timer = null;
  try {
    return await Promise.race([
      work,
      new Promise((resolve, reject) => { timer = setTimeout(() => reject(new Error('Timed out waiting for data writes')), timeoutMs); }),
    ]);
  } finally {
    if (timer) clearTimeout(timer);
  }
}

function transactionRecordData(records) {
  return records.map(record => ({ target: record.target, staged: record.staged, rollback: record.rollback, hadOriginal: record.hadOriginal }));
}

async function cleanupTransactionRecords(records) {
  for (const record of records) {
    await fs.promises.rm(record.staged, { force: true }).catch(() => { });
    await fs.promises.rm(record.rollback, { force: true }).catch(() => { });
  }
}

async function rollbackDataTransaction(records) {
  let rollbackSucceeded = true;
  for (const record of records.slice().reverse()) {
    try {
      if (record.hadOriginal) await fs.promises.copyFile(record.rollback, record.target);
      else await fs.promises.rm(record.target, { force: true });
    } catch (rollbackError) {
      rollbackSucceeded = false;
      console.error('Backup restore rollback failed:', record.target, rollbackError);
    }
  }
  return rollbackSucceeded;
}

async function replaceJsonFilesTransactionInner(entries) {
  const transactionId = `${process.pid}.${Date.now()}.${crypto.randomBytes(6).toString('hex')}`;
  const records = entries.map((entry) => ({
    target: entry.filePath,
    text: JSON.stringify(entry.data),
    staged: path.join(path.dirname(entry.filePath), `.${path.basename(entry.filePath)}.${transactionId}.stage`),
    rollback: path.join(path.dirname(entry.filePath), `.${path.basename(entry.filePath)}.${transactionId}.rollback`),
    hadOriginal: false,
  }));
  let manifestWritten = false;
  let commitComplete = false;
  try {
    for (const record of records) await fs.promises.writeFile(record.staged, record.text, { encoding: 'utf8', mode: 0o600 });
    for (const record of records) {
      try {
        const stat = await fs.promises.lstat(record.target);
        if (!stat.isFile() || stat.isSymbolicLink()) throw new Error(`Invalid data file: ${path.basename(record.target)}`);
        record.hadOriginal = true;
        await fs.promises.copyFile(record.target, record.rollback, fs.constants.COPYFILE_EXCL);
      } catch (e) {
        if (e.code !== 'ENOENT') throw e;
      }
    }
    await writeTextFileAtomic(RESTORE_MANIFEST_FILE, JSON.stringify({ phase: 'prepared', records: transactionRecordData(records) }));
    manifestWritten = true;
    for (const record of records) await fs.promises.rename(record.staged, record.target);
    await writeTextFileAtomic(RESTORE_MANIFEST_FILE, JSON.stringify({ phase: 'committed', records: transactionRecordData(records) }));
    commitComplete = true;
    await cleanupTransactionRecords(records);
    await fs.promises.rm(RESTORE_MANIFEST_FILE, { force: true }).catch((e) => console.warn('Committed restore manifest will be cleaned on next startup:', e));
  } catch (error) {
    if (commitComplete) {
      console.warn('Backup restore committed; deferred transaction cleanup:', error);
      return;
    }
    if (manifestWritten) {
      const rolledBack = await rollbackDataTransaction(records);
      if (rolledBack) {
        await writeTextFileAtomic(RESTORE_MANIFEST_FILE, JSON.stringify({ phase: 'rolled-back', records: transactionRecordData(records) }));
        await cleanupTransactionRecords(records);
        await fs.promises.rm(RESTORE_MANIFEST_FILE, { force: true }).catch((e) => console.warn('Rolled-back restore manifest will be cleaned on next startup:', e));
      }
    } else {
      await cleanupTransactionRecords(records);
    }
    throw error;
  }
}

async function replaceJsonFilesTransaction(entries) {
  if (activeDataTransactionPromise) throw new Error('Another data transaction is already active');
  const transaction = replaceJsonFilesTransactionInner(entries);
  activeDataTransactionPromise = transaction;
  try { return await transaction; }
  finally { if (activeDataTransactionPromise === transaction) activeDataTransactionPromise = null; }
}

async function recoverInterruptedDataTransaction() {
  if (!fs.existsSync(RESTORE_MANIFEST_FILE)) return;
  try {
    const manifest = JSON.parse(await fs.promises.readFile(RESTORE_MANIFEST_FILE, 'utf8'));
    const records = Array.isArray(manifest.records) ? manifest.records : [];
    const legacyTargets = [LIBRARY_FILE, PLAYLISTS_FILE, MAPPINGS_FILE, SETTINGS_FILE];
    const currentTargets = [...legacyTargets, LIKED_SONGS_FILE];
    const allowedTargets = new Set(currentTargets);
    const recordTargets = new Set(records.map(record => record && record.target));
    const hasExactTargets = (targets) => recordTargets.size === targets.length && targets.every(target => recordTargets.has(target));
    const userDataDir = app.getPath('userData');
    const valid = ((records.length === 4 && hasExactTargets(legacyTargets)) || (records.length === 5 && hasExactTargets(currentTargets)))
      && records.every(record => record
      && typeof record.target === 'string'
      && typeof record.staged === 'string'
      && typeof record.rollback === 'string'
      && allowedTargets.has(record.target)
      && path.dirname(record.staged) === userDataDir
      && path.dirname(record.rollback) === userDataDir
      && path.basename(record.staged).startsWith(`.${path.basename(record.target)}.`)
      && path.basename(record.staged).endsWith('.stage')
      && path.basename(record.rollback).startsWith(`.${path.basename(record.target)}.`)
      && path.basename(record.rollback).endsWith('.rollback')
      && typeof record.hadOriginal === 'boolean');
    if (!valid) throw new Error('Invalid restore recovery manifest');
    if (manifest.phase !== 'committed' && manifest.phase !== 'rolled-back') {
      const rolledBack = await rollbackDataTransaction(records);
      if (!rolledBack) throw new Error('Backup restore rollback is incomplete');
      await writeTextFileAtomic(RESTORE_MANIFEST_FILE, JSON.stringify({ phase: 'rolled-back', records: transactionRecordData(records) }));
    }
    await cleanupTransactionRecords(records);
    await fs.promises.rm(RESTORE_MANIFEST_FILE, { force: true }).catch((e) => console.warn('Completed recovery manifest cleanup deferred:', e));
  } catch (e) {
    console.error('Could not recover interrupted backup restore:', e);
    throw e;
  }
}

function sanitizeSettingsForBackup(settings) {
  const next = { ...(settings || {}) };
  for (const key of SENSITIVE_SETTING_KEYS) delete next[key];
  return next;
}

function summarizeBackupData(data) {
  return {
    library: Array.isArray(data && data.library) ? data.library.length : 0,
    playlists: Array.isArray(data && data.playlists) ? data.playlists.length : 0,
    likedSongs: Array.isArray(data && data.likedSongs) ? data.likedSongs.length : 0,
    hasSettings: !!(data && data.settings && typeof data.settings === 'object'),
    hasMappings: !!(data && data.mappings && typeof data.mappings === 'object'),
  };
}

function isPlainObject(value) {
  return !!value && typeof value === 'object' && !Array.isArray(value) && Object.getPrototypeOf(value) === Object.prototype;
}

function backupSettingError(key, message) {
  throw new Error(`Backup setting "${key}" ${message}`);
}

function boundedBackupString(value, key, maxLength = 4096, allowEmpty = true) {
  if (typeof value !== 'string') backupSettingError(key, 'must be a string');
  if ((!allowEmpty && !value) || value.length > maxLength || value.includes('\0')) backupSettingError(key, 'contains an invalid string value');
  return value;
}

function boundedBackupNumber(value, key, min, max, integer = false) {
  const number = typeof value === 'string' && value.trim() ? Number(value) : value;
  if (typeof number !== 'number' || !Number.isFinite(number) || number < min || number > max || (integer && !Number.isInteger(number))) {
    backupSettingError(key, 'contains an invalid number');
  }
  return number;
}

function sanitizeShortcutList(shortcuts, key = 'shortcuts') {
  if (!Array.isArray(shortcuts) || shortcuts.length > 32) backupSettingError(key, 'must be an array of at most 32 shortcuts');
  return shortcuts.map((shortcut, index) => {
    const itemKey = `${key}[${index}]`;
    if (!isPlainObject(shortcut)) backupSettingError(itemKey, 'must be an object');
    const id = boundedBackupString(shortcut.id, `${itemKey}.id`, 80, false);
    const label = boundedBackupString(shortcut.label, `${itemKey}.label`, 160, false);
    const action = boundedBackupString(shortcut.action, `${itemKey}.action`, 40, false);
    const accelerator = boundedBackupString(shortcut.accelerator, `${itemKey}.accelerator`, 100);
    if (!SHORTCUT_ACTIONS.has(action)) backupSettingError(`${itemKey}.action`, 'is not supported');
    if (typeof shortcut.enabled !== 'boolean') backupSettingError(`${itemKey}.enabled`, 'must be a boolean');
    if (shortcut.enabled && !accelerator) backupSettingError(`${itemKey}.accelerator`, 'is required for an enabled shortcut');
    if (/[\u0000-\u001f\u007f]/.test(accelerator)) backupSettingError(`${itemKey}.accelerator`, 'contains control characters');
    return { id, label, action, accelerator, enabled: shortcut.enabled };
  });
}

function sanitizeTrackReference(value, key) {
  if (!isPlainObject(value)) backupSettingError(key, 'must be an object');
  const next = {};
  const legacyFilePath = isPlainObject(value.matchedFile) ? value.matchedFile.filePath : null;
  const filePath = value.filePath !== undefined && value.filePath !== null ? value.filePath : legacyFilePath;
  if (filePath !== undefined && filePath !== null) next.filePath = boundedBackupString(filePath, `${key}.filePath`, 4096, false);
  else next.filePath = null;
  for (const field of ['title', 'artist', 'album']) {
    if (value[field] !== undefined && value[field] !== null) next[field] = boundedBackupString(value[field], `${key}.${field}`, 2000);
  }
  if (value.duration !== undefined && value.duration !== null) next.duration = boundedBackupNumber(value.duration, `${key}.duration`, 0, 7 * 24 * 60 * 60);
  return next;
}

function sanitizeNumberMap(value, key, limits) {
  if (!isPlainObject(value)) backupSettingError(key, 'must be an object');
  const entries = Object.entries(value);
  if (entries.length > limits.maxItems) backupSettingError(key, 'contains too many entries');
  const next = {};
  for (const [entryKey, entryValue] of entries) {
    boundedBackupString(entryKey, `${key} key`, limits.maxKeyLength || 4096, false);
    next[entryKey] = boundedBackupNumber(entryValue, `${key}.${entryKey}`, limits.min, limits.max, !!limits.integer);
  }
  return next;
}

function sanitizeCustomSmartPlaylists(value) {
  if (!Array.isArray(value) || value.length > 100) backupSettingError('customSmartPlaylists', 'must be an array of at most 100 entries');
  const fields = new Set(['artist', 'album', 'genre', 'year', 'decade', 'playHistory', 'liked', 'unplayed', 'duration_min', 'duration_max', 'no_genre']);
  return value.map((playlist, index) => {
    const key = `customSmartPlaylists[${index}]`;
    if (!isPlainObject(playlist) || !isPlainObject(playlist.rule)) backupSettingError(key, 'must contain a rule object');
    const field = boundedBackupString(playlist.rule.field, `${key}.rule.field`, 40, false);
    if (!fields.has(field)) backupSettingError(`${key}.rule.field`, 'is not supported');
    const nextRule = { field };
    if (playlist.rule.value !== undefined) {
      nextRule.value = field === 'duration_min' || field === 'duration_max'
        ? boundedBackupNumber(playlist.rule.value, `${key}.rule.value`, 0, 7 * 24 * 60 * 60)
        : boundedBackupString(playlist.rule.value, `${key}.rule.value`, 500);
    }
    if (playlist.rule.limit !== undefined) nextRule.limit = boundedBackupNumber(playlist.rule.limit, `${key}.rule.limit`, 1, 1000, true);
    const color = boundedBackupString(playlist.color || '', `${key}.color`, 100);
    if (color && !/^linear-gradient\(\d{1,3}deg,#[0-9a-f]{6},#[0-9a-f]{6}\)$/i.test(color)) backupSettingError(`${key}.color`, 'is invalid');
    const icon = boundedBackupString(playlist.icon || '', `${key}.icon`, 80);
    if (icon && !/^ph-[a-z0-9-]+$/.test(icon)) backupSettingError(`${key}.icon`, 'is invalid');
    return {
      id: boundedBackupString(playlist.id, `${key}.id`, 120, false),
      name: boundedBackupString(playlist.name, `${key}.name`, 500, false),
      icon,
      color,
      type: 'smart',
      rule: nextRule,
      desc: boundedBackupString(playlist.desc || '', `${key}.desc`, 1000),
    };
  });
}

function sanitizeImportedSettings(settings) {
  if (!isPlainObject(settings)) throw new Error('Backup settings must be an object');
  const next = {};
  const booleanKeys = [
    'minimizeToTray', 'useNativeTitleBar', 'discordRpc', 'normalization', 'notifications',
    'virtualScrolling', 'lazyLoading', 'glassEffects', 'npLyricsVisible', 'sortAscending',
    'likedSongsSortAscending', 'isPlaylistGridView',
  ];
  for (const key of booleanKeys) {
    if (!Object.prototype.hasOwnProperty.call(settings, key)) continue;
    if (typeof settings[key] !== 'boolean') backupSettingError(key, 'must be a boolean');
    next[key] = settings[key];
  }

  const enumSettings = {
    audioMode: new Set(['stereo', 'mono']),
    ytdlCookiesMode: new Set(['none', 'browser', 'file']),
    ytdlCookiesBrowser: new Set(['firefox', 'chrome', 'chromium', 'brave', 'edge', 'vivaldi', 'opera']),
    likedSongsSortBy: new Set(['Title', 'Artist', 'Album', 'Recently Added']),
  };
  for (const [key, allowed] of Object.entries(enumSettings)) {
    if (!Object.prototype.hasOwnProperty.call(settings, key)) continue;
    const value = boundedBackupString(settings[key], key, 40, false);
    if (!allowed.has(value)) backupSettingError(key, 'is not supported');
    next[key] = value;
  }

  const stringSettings = { ytdlDownloadFolder: 4096, ytdlCookiesFile: 4096, lastfmUsername: 500 };
  for (const [key, maxLength] of Object.entries(stringSettings)) {
    if (!Object.prototype.hasOwnProperty.call(settings, key)) continue;
    if (key === 'lastfmUsername' && settings[key] === null) next[key] = null;
    else next[key] = boundedBackupString(settings[key], key, maxLength);
  }

  const numberSettings = {
    sidebarWidth: [120, 2000, true],
    crossfade: [0, 10, false],
    masterGain: [0, 100, false],
    volume: [0, 1, false],
    folderCoversBackfilledVersion: [0, 100, true],
    savedQueueIndex: [0, 250000, true],
  };
  for (const [key, limits] of Object.entries(numberSettings)) {
    if (Object.prototype.hasOwnProperty.call(settings, key)) next[key] = boundedBackupNumber(settings[key], key, ...limits);
  }

  if (Object.prototype.hasOwnProperty.call(settings, 'accentColor')) {
    const accentColor = boundedBackupString(settings.accentColor, 'accentColor', 7, false);
    if (!/^#[0-9a-f]{6}$/i.test(accentColor)) backupSettingError('accentColor', 'must be a six-digit hex color');
    next.accentColor = accentColor;
  }
  if (Object.prototype.hasOwnProperty.call(settings, 'themeColors')) {
    if (!isPlainObject(settings.themeColors)) backupSettingError('themeColors', 'must be an object');
    const colors = {};
    for (const key of ['accent', 'bg', 'panel', 'glass', 'border', 'text', 'muted', 'danger']) {
      if (!Object.prototype.hasOwnProperty.call(settings.themeColors, key)) continue;
      const color = boundedBackupString(settings.themeColors[key], `themeColors.${key}`, 7, false);
      if (!/^#[0-9a-f]{6}$/i.test(color)) backupSettingError(`themeColors.${key}`, 'must be a six-digit hex color');
      colors[key] = color;
    }
    next.themeColors = colors;
  }
  if (Object.prototype.hasOwnProperty.call(settings, 'eqGains')) {
    if (!Array.isArray(settings.eqGains) || settings.eqGains.length !== 5) backupSettingError('eqGains', 'must contain five bands');
    next.eqGains = settings.eqGains.map((gain, index) => boundedBackupNumber(gain, `eqGains[${index}]`, -12, 12));
  }
  if (Object.prototype.hasOwnProperty.call(settings, 'libraryRoots')) {
    if (!Array.isArray(settings.libraryRoots) || settings.libraryRoots.length > 512) backupSettingError('libraryRoots', 'must be an array of at most 512 paths');
    next.libraryRoots = Array.from(new Set(settings.libraryRoots.map((root, index) => boundedBackupString(root, `libraryRoots[${index}]`, 4096, false))));
  }
  if (Object.prototype.hasOwnProperty.call(settings, 'savedQueue')) {
    if (!Array.isArray(settings.savedQueue) || settings.savedQueue.length > 250000) backupSettingError('savedQueue', 'must be an array of at most 250000 paths');
    next.savedQueue = settings.savedQueue.map((filePath, index) => boundedBackupString(filePath, `savedQueue[${index}]`, 4096, false));
  }
  if (Object.prototype.hasOwnProperty.call(settings, 'shortcuts')) next.shortcuts = sanitizeShortcutList(settings.shortcuts);
  if (Object.prototype.hasOwnProperty.call(settings, 'lastTrack')) next.lastTrack = sanitizeTrackReference(settings.lastTrack, 'lastTrack');
  if (Object.prototype.hasOwnProperty.call(settings, 'playHistory')) {
    if (!Array.isArray(settings.playHistory) || settings.playHistory.length > 50) backupSettingError('playHistory', 'must be an array of at most 50 tracks');
    next.playHistory = settings.playHistory.map((track, index) => sanitizeTrackReference(track, `playHistory[${index}]`));
  }
  if (Object.prototype.hasOwnProperty.call(settings, 'lastPlayed')) {
    if (!isPlainObject(settings.lastPlayed)) backupSettingError('lastPlayed', 'must be an object');
    next.lastPlayed = { path: boundedBackupString(settings.lastPlayed.path, 'lastPlayed.path', 4096, false) };
  }
  if (Object.prototype.hasOwnProperty.call(settings, 'lyricsOffsets')) {
    next.lyricsOffsets = sanitizeNumberMap(settings.lyricsOffsets, 'lyricsOffsets', { maxItems: 10000, maxKeyLength: 2000, min: -3600, max: 3600 });
  }
  if (Object.prototype.hasOwnProperty.call(settings, 'playCounts')) {
    next.playCounts = sanitizeNumberMap(settings.playCounts, 'playCounts', { maxItems: 250000, min: 0, max: 1000000000, integer: true });
  }
  if (Object.prototype.hasOwnProperty.call(settings, 'playTimes')) {
    next.playTimes = sanitizeNumberMap(settings.playTimes, 'playTimes', { maxItems: 250000, min: 0, max: 1000000000000 });
  }
  if (Object.prototype.hasOwnProperty.call(settings, 'customSmartPlaylists')) next.customSmartPlaylists = sanitizeCustomSmartPlaylists(settings.customSmartPlaylists);
  return next;
}

function validateBackupJsonShape(value, depth, budget) {
  if (--budget.remaining < 0) throw new Error('Backup contains too many values');
  if (value === null || typeof value === 'boolean') return;
  if (typeof value === 'number') {
    if (!Number.isFinite(value)) throw new Error('Backup contains an invalid number');
    return;
  }
  if (typeof value === 'string') {
    if (value.length > 16 * 1024 * 1024) throw new Error('Backup contains an oversized value');
    return;
  }
  if (depth >= 12) throw new Error('Backup nesting is too deep');
  if (Array.isArray(value)) {
    if (value.length > 500000) throw new Error('Backup contains an oversized array');
    for (const item of value) validateBackupJsonShape(item, depth + 1, budget);
    return;
  }
  if (!isPlainObject(value)) throw new Error('Backup contains an invalid value');
  const keys = Object.keys(value);
  if (keys.length > 500000) throw new Error('Backup object has too many fields');
  for (const key of keys) {
    if (key === '__proto__' || key === 'prototype' || key === 'constructor') throw new Error('Backup contains a forbidden field');
    validateBackupJsonShape(value[key], depth + 1, budget);
  }
}

function validateBackupStringField(record, field, key, maxLength, options = {}) {
  if (!Object.prototype.hasOwnProperty.call(record, field)) {
    if (options.required) throw new Error(`${key}.${field} is required`);
    return;
  }
  const value = record[field];
  if (value === null && options.nullable) return;
  if (typeof value !== 'string' || value.length > maxLength || value.includes('\0') || (options.nonEmpty && !value)) {
    throw new Error(`${key}.${field} must be ${options.nonEmpty ? 'a non-empty ' : 'a '}string of at most ${maxLength} characters`);
  }
}

function validateBackupNumberField(record, field, key, min, max, integer = false, nullable = true) {
  if (!Object.prototype.hasOwnProperty.call(record, field)) return;
  const value = record[field];
  if (value === null && nullable) return;
  if (typeof value !== 'number' || !Number.isFinite(value) || value < min || value > max || (integer && !Number.isInteger(value))) {
    throw new Error(`${key}.${field} contains an invalid number`);
  }
}

function validateBackupLibrary(library) {
  if (library.length > MAX_LIBRARY_TRACKS) throw new Error(`Backup library contains more than ${MAX_LIBRARY_TRACKS} tracks`);
  for (let index = 0; index < library.length; index++) {
    const track = library[index];
    const key = `library[${index}]`;
    if (!isPlainObject(track)) throw new Error(`Backup ${key} must be an object`);
    validateBackupStringField(track, 'filePath', key, 4096, { required: true, nonEmpty: true });
    validateBackupStringField(track, 'filename', key, 1024, { required: true, nonEmpty: true });
    for (const field of ['title', 'artist', 'album']) validateBackupStringField(track, field, key, 2000, { required: true });
    validateBackupStringField(track, 'albumArtist', key, 2000, { nullable: true });
    validateBackupStringField(track, 'picture', key, 16384, { nullable: true });
    validateBackupStringField(track, 'genre', key, 2000, { nullable: true });
    if (Object.prototype.hasOwnProperty.call(track, 'year') && track.year !== null) {
      if (typeof track.year === 'string') {
        if (track.year.length > 40 || track.year.includes('\0')) throw new Error(`${key}.year is invalid`);
      } else if (typeof track.year !== 'number' || !Number.isFinite(track.year)) throw new Error(`${key}.year must be a string, number, or null`);
    }
    validateBackupNumberField(track, 'duration', key, 0, 7 * 24 * 60 * 60);
    for (const field of ['trackNo', 'trackTotal', 'discNo', 'discTotal', '__displayDiscNo']) validateBackupNumberField(track, field, key, 0, 100000, true);
    validateBackupNumberField(track, 'fileSize', key, 0, Number.MAX_SAFE_INTEGER, true);
    validateBackupNumberField(track, 'modifiedAtMs', key, 0, Number.MAX_SAFE_INTEGER);
    validateBackupNumberField(track, 'addedAtMs', key, 0, Number.MAX_SAFE_INTEGER);
    for (const field of ['replayGainTrackDb', 'replayGainAlbumDb']) validateBackupNumberField(track, field, key, -1000, 1000);
    for (const field of ['replayGainTrackPeak', 'replayGainAlbumPeak']) validateBackupNumberField(track, field, key, 0, 1000000);
    if (Object.prototype.hasOwnProperty.call(track, 'isDisabled') && typeof track.isDisabled !== 'boolean') throw new Error(`${key}.isDisabled must be a boolean`);
  }
}

const PLAYLIST_TRACK_STRING_FIELDS = new Set([
  'Song', 'song', 'title', 'Title', 'TITLE', 'Name', 'name',
  'Artist', 'artist', 'ARTIST', 'Album', 'album', 'ALBUM', 'AlbumArtist',
  'FilePath', 'filePath', 'Path', 'path', 'Playlist',
]);

function validateBackupPlaylistTrack(track, key) {
  if (!isPlainObject(track)) throw new Error(`Backup ${key} must be an object`);
  const entries = Object.entries(track);
  if (entries.length > 128) throw new Error(`Backup ${key} has too many CSV fields`);
  for (const [field, value] of entries) {
    if (field.length > 256 || field.includes('\0')) throw new Error(`Backup ${key} contains an invalid CSV field name`);
    if (PLAYLIST_TRACK_STRING_FIELDS.has(field)) {
      if (typeof value !== 'string' || value.length > (field.toLowerCase().includes('path') ? 4096 : 2000) || value.includes('\0')) {
        throw new Error(`Backup ${key}.${field} must be a bounded string`);
      }
      continue;
    }
    if (typeof value === 'string') {
      if (value.length > 16384 || value.includes('\0')) throw new Error(`Backup ${key}.${field} contains an oversized string`);
    } else if (typeof value === 'number') {
      if (!Number.isFinite(value)) throw new Error(`Backup ${key}.${field} contains an invalid number`);
    } else if (value !== null && typeof value !== 'boolean') {
      throw new Error(`Backup ${key}.${field} must be a primitive CSV value`);
    }
  }
}

function validateBackupPlaylists(playlists) {
  if (playlists.length > MAX_PLAYLISTS) throw new Error(`Backup contains more than ${MAX_PLAYLISTS} playlists`);
  const playlistIds = new Set();
  let trackCount = 0;
  for (let index = 0; index < playlists.length; index++) {
    const playlist = playlists[index];
    const key = `playlists[${index}]`;
    if (!isPlainObject(playlist)) throw new Error(`Backup ${key} must be an object`);
    validateBackupStringField(playlist, 'id', key, 500, { required: true, nonEmpty: true });
    validateBackupStringField(playlist, 'name', key, 1000, { required: true, nonEmpty: true });
    if (playlistIds.has(playlist.id)) throw new Error(`Backup contains duplicate playlist id "${playlist.id}"`);
    playlistIds.add(playlist.id);
    if (!Array.isArray(playlist.tracks)) throw new Error(`Backup ${key}.tracks must be an array`);
    trackCount += playlist.tracks.length;
    if (trackCount > MAX_PLAYLIST_TRACKS) throw new Error(`Backup contains more than ${MAX_PLAYLIST_TRACKS} playlist tracks`);
    if (Object.prototype.hasOwnProperty.call(playlist, 'color')) {
      if (typeof playlist.color !== 'string' || !PLAYLIST_COLORS.has(playlist.color)) throw new Error(`Backup ${key}.color is invalid`);
    }
    validateBackupStringField(playlist, 'cover', key, 16384, { nullable: true });
    validateBackupStringField(playlist, 'lastPlayed', key, 100, { nullable: true });
    validateBackupStringField(playlist, 'sortBy', key, 100, { nullable: true });
    for (const field of ['pinned', 'isSpecial']) {
      if (Object.prototype.hasOwnProperty.call(playlist, field) && typeof playlist[field] !== 'boolean') throw new Error(`Backup ${key}.${field} must be a boolean`);
    }
    for (let trackIndex = 0; trackIndex < playlist.tracks.length; trackIndex++) {
      validateBackupPlaylistTrack(playlist.tracks[trackIndex], `${key}.tracks[${trackIndex}]`);
    }
  }
}

function validateBackupMappings(mappings) {
  const entries = Object.entries(mappings);
  if (entries.length > MAX_LIBRARY_TRACKS) throw new Error('Backup mappings contain too many entries');
  for (const [key, value] of entries) {
    if (!key || key.length > 6000 || key.includes('\0')) throw new Error('Backup mappings contain an invalid key');
    if (typeof value !== 'string' || !value || value.length > 4096 || value.includes('\0')) throw new Error(`Backup mapping "${key.slice(0, 100)}" must be a bounded path or NO_MATCH string`);
  }
}

function validateBackupContainers(data, requireLikedSongs = false) {
  if (!Array.isArray(data.library)) throw new Error('Backup library must be an array');
  if (!Array.isArray(data.playlists)) throw new Error('Backup playlists must be an array');
  if (!isPlainObject(data.mappings)) throw new Error('Backup mappings must be an object');
  if (!isPlainObject(data.settings)) throw new Error('Backup settings must be an object');
  if (requireLikedSongs && !Array.isArray(data.likedSongs)) throw new Error('Backup liked songs must be an array');
  if (data.likedSongs !== undefined) {
    if (!Array.isArray(data.likedSongs) || data.likedSongs.length > MAX_LIBRARY_TRACKS) throw new Error('Backup liked songs are invalid');
    data.likedSongs.forEach((filePath, index) => {
      if (typeof filePath !== 'string' || !filePath || filePath.length > 4096 || filePath.includes('\0')) throw new Error(`Backup likedSongs[${index}] must be a bounded path string`);
    });
  }
  validateBackupLibrary(data.library);
  validateBackupPlaylists(data.playlists);
  validateBackupMappings(data.mappings);
}

function validateBackupData(parsed) {
  if (!isPlainObject(parsed)) throw new Error('Backup root must be an object');
  let data = parsed;
  if (Object.prototype.hasOwnProperty.call(parsed, 'data')) {
    if (parsed.app !== APP_NAME || parsed.schemaVersion !== 1) throw new Error('Unsupported backup format or version');
    data = parsed.data;
  } else {
    const legacyFields = ['library', 'playlists', 'mappings', 'settings'];
    if (!legacyFields.every(key => Object.prototype.hasOwnProperty.call(parsed, key))) throw new Error('Unsupported legacy backup format');
  }
  if (!isPlainObject(data)) throw new Error('Backup data must be an object');
  validateBackupJsonShape(data, 0, { remaining: MAX_BACKUP_VALUES });
  validateBackupContainers(data);
  return { ...data, settings: sanitizeImportedSettings(data.settings) };
}

function validateAppStateSnapshot(snapshot) {
  if (!isPlainObject(snapshot)) throw new Error('App state snapshot must be an object');
  const playlists = Array.isArray(snapshot.playlists) ? snapshot.playlists.map((playlist) => {
    if (!isPlainObject(playlist) || !Array.isArray(playlist.tracks)) return playlist;
    return {
      ...playlist,
      tracks: playlist.tracks.map((track) => {
        if (!isPlainObject(track)) return track;
        return Object.fromEntries(Object.entries(track).filter(([key]) => !key.startsWith('__')));
      }),
    };
  }) : snapshot.playlists;
  const data = {
    library: snapshot.library,
    playlists,
    mappings: snapshot.mappings,
    settings: snapshot.settings,
    likedSongs: snapshot.likedSongs,
  };
  validateBackupJsonShape(data, 0, { remaining: MAX_BACKUP_VALUES });
  validateBackupContainers(data, true);
  const settings = sanitizeImportedSettings(data.settings);
  for (const key of SENSITIVE_SETTING_KEYS) {
    if (!Object.prototype.hasOwnProperty.call(data.settings, key)) continue;
    settings[key] = boundedBackupString(data.settings[key], key, 16384);
  }
  return { ...data, settings };
}


async function loadMM() {
  mm = await import('music-metadata');
}

async function finishCloseAfterRendererFlush() {
  if (closeFinishInProgress) return;
  closeFinishInProgress = true;
  if (quitFlushTimer) clearTimeout(quitFlushTimer);
  quitFlushTimer = null;
  quitFlushPending = false;
  const action = pendingCloseAction;
  pendingCloseAction = '';
  try { await waitForPendingDataWrites(1800); }
  catch (e) { console.error('Failed to finish pending data writes before close:', e); }
  if (action === 'close-window' && mainWindow && !mainWindow.isDestroyed()) {
    allowWindowClose = true;
    closeFinishInProgress = false;
    mainWindow.close();
    return;
  }
  isQuitting = true;
  app.quit();
}

function requestRendererFlushBeforeClose(action) {
  if (quitFlushPending) { if (action === 'quit') pendingCloseAction = 'quit'; return; }
  if (!mainWindow || mainWindow.isDestroyed() || mainWindow.webContents.isDestroyed()) {
    pendingCloseAction = action;
    finishCloseAfterRendererFlush();
    return;
  }
  quitFlushPending = true;
  pendingCloseAction = action;
  mainWindow.webContents.send('prepare-app-close');
  quitFlushTimer = setTimeout(finishCloseAfterRendererFlush, 1800);
}

function createWindow() {
  mainWindow = new BrowserWindow({
    title: APP_NAME,
    width: 1200,
    height: 800,
    minWidth: 980,
    minHeight: 640,
    frame: appSettings.useNativeTitleBar === true,
    icon: APP_ICON,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true
    },
    autoHideMenuBar: true,
    backgroundColor: '#000000'
  });

  const preventUntrustedNavigation = (event, url) => {
    const targetUrl = typeof url === 'string' ? url : event.url;
    if (targetUrl !== APP_ENTRY_URL) event.preventDefault();
  };
  mainWindow.webContents.on('will-navigate', preventUntrustedNavigation);
  mainWindow.webContents.on('will-frame-navigate', preventUntrustedNavigation);
  mainWindow.webContents.setWindowOpenHandler(() => ({ action: 'deny' }));
  mainWindow.webContents.session.setPermissionRequestHandler((webContents, permission, callback) => {
    callback(webContents === mainWindow.webContents && permission === 'notifications');
  });
  mainWindow.webContents.session.setPermissionCheckHandler((webContents, permission) => {
    return webContents === mainWindow.webContents && permission === 'notifications';
  });

  mainWindow.loadFile('index.html');

  mainWindow.on('close', (event) => {
    if (allowWindowClose) { allowWindowClose = false; return; }
    if (!isQuitting && appSettings.minimizeToTray && trayAvailable) {
      event.preventDefault();
      mainWindow.hide();
      return;
    }
    if (!isQuitting) {
      event.preventDefault();
      requestRendererFlushBeforeClose(process.platform === 'darwin' ? 'close-window' : 'quit');
    }
  });
}

function showMainWindow() {
  if (!mainWindow) return;
  if (mainWindow.isMinimized()) mainWindow.restore();
  mainWindow.show();
  mainWindow.focus();
}

function sendPlayerAction(action, detail) {
  if (!mainWindow || mainWindow.isDestroyed() || mainWindow.webContents.isDestroyed()) return false;
  try {
    mainWindow.webContents.send('thumbar-action', action, detail);
    return true;
  } catch (e) {
    console.log('Player integration action failed:', e && e.message ? e.message : e);
    return false;
  }
}

function getCurrentMprisTrackId() {
  if (!mprisPlayer || !mprisTrackKey) return '';
  return mprisPlayer.objectPath(`track/${mprisTrackId}`);
}

function initMprisPlayer() {
  if (process.platform !== 'linux' || mprisPlayer) return;
  try {
    const MprisService = require('mpris-service');
    mprisPlayer = MprisService({
      name: APP_ID,
      identity: APP_NAME,
      desktopEntry: APP_ID,
      supportedUriSchemes: ['file'],
      supportedMimeTypes: ['audio/mpeg', 'audio/flac', 'audio/mp4', 'audio/wav', 'audio/x-wav'],
      supportedInterfaces: ['player']
    });

    mprisPlayer.playbackStatus = 'Stopped';
    mprisPlayer.loopStatus = 'None';
    mprisPlayer.rate = 1;
    mprisPlayer.minimumRate = 1;
    mprisPlayer.maximumRate = 1;
    mprisPlayer.volume = 1;
    mprisPlayer.canControl = true;
    mprisPlayer.canPlay = true;
    mprisPlayer.canPause = true;
    mprisPlayer.canSeek = true;
    mprisPlayer.canGoNext = true;
    mprisPlayer.canGoPrevious = true;

    mprisPlayer.getPosition = function () {
      if (mprisPlayer.playbackStatus !== 'Playing') return Math.max(0, Math.floor(mprisPositionUs));
      const elapsedUs = Math.max(0, Date.now() - mprisPositionUpdatedAt) * 1000;
      const position = Math.max(0, Math.floor(mprisPositionUs + elapsedUs));
      return mprisDurationUs > 0 ? Math.min(position, mprisDurationUs) : position;
    };

    const onMpris = (name, handler) => mprisPlayer.on(name, (...args) => {
      try { handler(...args); }
      catch (e) { console.log(`MPRIS ${name} error:`, e && e.message ? e.message : e); }
    });
    onMpris('raise', showMainWindow);
    onMpris('quit', () => requestRendererFlushBeforeClose('quit'));
    onMpris('next', () => { mprisStopped = false; sendPlayerAction('next'); });
    onMpris('previous', () => { mprisStopped = false; sendPlayerAction('prev'); });
    onMpris('playpause', () => { mprisStopped = false; sendPlayerAction('playpause'); });
    onMpris('play', () => { mprisStopped = false; sendPlayerAction('play'); });
    onMpris('pause', () => { if (!mprisStopped) sendPlayerAction('pause'); });
    onMpris('stop', () => {
      mprisStopped = true;
      mprisPositionUs = 0;
      mprisPositionUpdatedAt = Date.now();
      sendPlayerAction('pause');
      sendPlayerAction('set-position', 0);
      mprisPlayer.playbackStatus = 'Stopped';
      try { mprisPlayer.seeked(0); } catch (_) { }
    });
    onMpris('seek', (offset) => {
      if (!mprisTrackKey || !Number.isFinite(offset)) return;
      sendPlayerAction('seek', Math.trunc(offset));
    });
    onMpris('position', (event) => {
      const position = event && Number(event.position);
      if (!event || String(event.trackId || '') !== getCurrentMprisTrackId() || !Number.isFinite(position) || position < 0) return;
      sendPlayerAction('set-position', Math.trunc(mprisDurationUs > 0 ? Math.min(position, mprisDurationUs) : position));
    });
    onMpris('shuffle', (enabled) => {
      const requested = enabled === true;
      mprisPlayer.shuffle = requested;
      sendPlayerAction('set-shuffle', requested);
    });
    onMpris('loopStatus', (status) => {
      if (!['None', 'Playlist', 'Track'].includes(status)) return;
      mprisPlayer.loopStatus = status;
      sendPlayerAction('set-loop-status', status);
    });
    onMpris('volume', (volume) => {
      if (!Number.isFinite(volume)) return;
      const safeVolume = Math.max(0, Math.min(1, volume));
      mprisPlayer.volume = safeVolume;
      sendPlayerAction('volume', safeVolume);
    });
    mprisPlayer.on('error', (err) => console.log('MPRIS error:', err && err.message ? err.message : err));
  } catch (e) {
    mprisPlayer = null;
    console.log('MPRIS unavailable:', e && e.message ? e.message : e);
  }
}

function updateMpris(payload) {
  try {
    return updateMprisInner(payload);
  } catch (e) {
    // D-Bus property setters can throw; a position tick must never crash the app
    console.log('MPRIS update error:', e && e.message ? e.message : e);
    return false;
  }
}

function updateMprisInner(payload) {
  if (!mprisPlayer || !payload || typeof payload !== 'object') return false;
  const hasTrack = !!payload.title;
  if (payload.isPlaying) mprisStopped = false;
  const status = hasTrack ? (payload.isPlaying ? 'Playing' : (mprisStopped ? 'Stopped' : 'Paused')) : 'Stopped';
  const rawPositionSeconds = Number(payload.positionSeconds || 0);
  const rawDurationSeconds = Number(payload.durationSeconds || 0);
  const positionSeconds = Number.isFinite(rawPositionSeconds) ? Math.max(0, rawPositionSeconds) : 0;
  const durationSeconds = Number.isFinite(rawDurationSeconds) ? Math.max(0, rawDurationSeconds) : 0;
  const trackKey = String(payload.filePath || `${payload.title || ''}::${payload.artist || ''}::${payload.album || ''}`);

  if (hasTrack && trackKey !== mprisTrackKey) {
    mprisTrackKey = trackKey;
    mprisTrackId++;
    if (payload.isPlaying) mprisStopped = false;
  }

  mprisPositionUs = Math.max(0, Math.floor(positionSeconds * 1000000));
  mprisDurationUs = Math.max(0, Math.floor(durationSeconds * 1000000));
  if (mprisDurationUs > 0) mprisPositionUs = Math.min(mprisPositionUs, mprisDurationUs);
  mprisPositionUpdatedAt = Date.now();
  mprisPlayer.playbackStatus = status;
  mprisPlayer.shuffle = !!payload.shuffle;
  mprisPlayer.loopStatus = payload.loopStatus || 'None';
  mprisPlayer.canSeek = durationSeconds > 0;
  mprisPlayer.volume = typeof payload.volume === 'number' ? payload.volume : mprisPlayer.volume;

  if (!hasTrack) {
    mprisTrackKey = '';
    mprisDurationUs = 0;
    mprisStopped = true;
    mprisPlayer.metadata = {};
    return true;
  }

  const metadata = {
    'mpris:trackid': getCurrentMprisTrackId(),
    'xesam:title': String(payload.title || 'Unknown Track'),
    'xesam:artist': [String(payload.artist || 'Unknown Artist')],
  };
  if (payload.album) metadata['xesam:album'] = String(payload.album);
  if (durationSeconds > 0) metadata['mpris:length'] = Math.floor(durationSeconds * 1000000);
  if (payload.artUrl) metadata['mpris:artUrl'] = String(payload.artUrl);
  if (payload.fileUrl) metadata['xesam:url'] = String(payload.fileUrl);
  mprisPlayer.metadata = metadata;
  if (payload.seeked) {
    try { mprisPlayer.seeked(mprisPositionUs); } catch (e) { }
  }
  return true;
}

function registerGlobalShortcut(accelerator, action, failures) {
  try {
    const registered = globalShortcut.register(accelerator, () => {
      sendPlayerAction(action);
    });
    if (!registered && failures) failures.push({ accelerator, action, error: 'Unavailable or already registered' });
    return registered;
  } catch (e) {
    if (failures) failures.push({ accelerator, action, error: e.message || String(e) });
    console.log('Failed to register shortcut:', accelerator, e.message || e);
    return false;
  }
}

function applyGlobalShortcuts(shortcuts) {
  let normalized;
  try { normalized = sanitizeShortcutList(shortcuts || DEFAULT_GLOBAL_SHORTCUTS); }
  catch (e) { return { ok: false, registered: [], failed: [{ error: e.message || String(e) }] }; }
  const result = { ok: true, registered: [], failed: [] };
  try { globalShortcut.unregisterAll(); }
  catch (e) {
    result.failed.push({ error: `Could not clear existing shortcuts: ${e.message || e}` });
    result.ok = false;
    return result;
  }
  for (const shortcut of normalized) {
    if (!shortcut.enabled || !shortcut.accelerator) continue;
    if (registerGlobalShortcut(shortcut.accelerator, shortcut.action, result.failed)) result.registered.push(shortcut.accelerator);
  }
  result.ok = result.failed.length === 0;
  return result;
}

async function reconcileDiscordRuntime(enabled) {
  const warnings = [];
  if (enabled) {
    await discordConnect();
    if (discordLastError) warnings.push(`Discord RPC could not be enabled: ${discordLastError}`);
    return warnings;
  }
  try {
    if (!(await discordClear())) warnings.push(`Discord RPC activity could not be cleared: ${discordLastError || 'unknown error'}`);
  } catch (e) { warnings.push(`Discord RPC activity could not be cleared: ${e.message || e}`); }
  if (discordClient) {
    try { await Promise.resolve(discordClient.destroy()); }
    catch (e) { warnings.push(`Discord RPC could not be disconnected: ${e.message || e}`); }
  }
  discordClient = null;
  discordEnabled = false;
  return warnings;
}

async function reconcileRestoredRuntime(settings) {
  const warnings = [];
  try { warnings.push(...await reconcileDiscordRuntime(settings.discordRpc === true)); }
  catch (e) { warnings.push(`Discord RPC runtime update failed: ${e.message || e}`); }
  try {
    const shortcutResult = applyGlobalShortcuts(settings.shortcuts || DEFAULT_GLOBAL_SHORTCUTS);
    for (const failure of shortcutResult.failed) {
      const shortcut = failure.accelerator ? `${failure.accelerator}: ` : '';
      warnings.push(`Global shortcut ${shortcut}${failure.error || 'registration failed'}`);
    }
  } catch (e) { warnings.push(`Global shortcut runtime update failed: ${e.message || e}`); }
  return warnings;
}

if (gotSingleInstanceLock) {
app.on('second-instance', () => {
  showMainWindow();
});

app.whenReady().then(async () => {
  if (process.platform === 'win32') app.setAppUserModelId('com.playerinyo.playerinyo');
  Menu.setApplicationMenu(null);
  try { await recoverInterruptedDataTransaction(); }
  catch (e) {
    dialog.showErrorBox('Playerinyo Recovery Failed', 'A previous backup restore could not be recovered safely. Playerinyo will close without loading potentially mixed data.\n\n' + (e.message || String(e)));
    app.quit();
    return;
  }
  loadSettingsFromDisk();
  await loadMM();
  createWindow();
  initMprisPlayer();

  try {
    const icon = nativeImage.createFromPath(APP_ICON);
    tray = new Tray(icon);
    const contextMenu = Menu.buildFromTemplate([
      { label: `Show ${APP_NAME}`, click: () => mainWindow.show() },
      {
        label: 'Quit', click: () => {
          requestRendererFlushBeforeClose('quit');
        }
      }
    ]);
    tray.setToolTip(APP_NAME);
    tray.setContextMenu(contextMenu);
    tray.on('click', () => mainWindow.show());
    trayAvailable = true;
  } catch (e) {
    trayAvailable = false;
    console.log("Tray init error:", e);
  }

  app.on('activate', function () {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });

  const shortcutResult = applyGlobalShortcuts(DEFAULT_GLOBAL_SHORTCUTS);
  if (!shortcutResult.ok) console.log('Default global shortcuts unavailable:', shortcutResult.failed);
}).catch((e) => handleFatalProcessError('Fatal startup error', e));
}

app.on('will-quit', () => {
  globalShortcut.unregisterAll();
});

app.on('window-all-closed', function () {
  if (process.platform !== 'darwin') app.quit();
});

// IPC Handler: Open Folder
registerIpcHandler('open-external', async (event, url) => {
  try {
    const parsed = new URL(String(url || ''));
    if (parsed.protocol !== 'https:' || parsed.username || parsed.password || !EXTERNAL_URL_HOSTS.has(parsed.hostname.toLowerCase())) return false;
    await shell.openExternal(parsed.href);
    return true;
  } catch (e) {
    return false;
  }
});

registerIpcHandler('show-item-in-folder', async (event, fullPath) => {
  fullPath = normalizePathInput(fullPath);
  if (typeof fullPath !== 'string' || !path.isAbsolute(fullPath) || !fs.existsSync(fullPath)) return false;
  shell.showItemInFolder(fullPath);
  return true;
});

let miniPlayerRestore = null;
registerIpcHandler('mini-player-mode', (event, enable) => {
  if (!mainWindow || mainWindow.isDestroyed()) return false;
  try {
    if (enable) {
      if (!miniPlayerRestore) miniPlayerRestore = { bounds: mainWindow.getBounds(), maximized: mainWindow.isMaximized() };
      if (mainWindow.isMaximized()) mainWindow.unmaximize();
      mainWindow.setMinimumSize(340, 150);
      mainWindow.setSize(420, 150);
      mainWindow.setAlwaysOnTop(true, 'floating');
    } else {
      mainWindow.setAlwaysOnTop(false);
      mainWindow.setMinimumSize(980, 640);
      if (miniPlayerRestore) {
        mainWindow.setBounds(miniPlayerRestore.bounds);
        if (miniPlayerRestore.maximized) mainWindow.maximize();
        miniPlayerRestore = null;
      } else {
        mainWindow.setSize(1200, 800);
      }
    }
    return true;
  } catch (e) {
    console.log('mini-player-mode error:', e && e.message ? e.message : e);
    return false;
  }
});

registerIpcHandler('window-control', async (event, action) => {
  const win = BrowserWindow.fromWebContents(event.sender);
  if (!win) return false;
  if (action === 'minimize') win.minimize();
  else if (action === 'toggle-maximize') win.isMaximized() ? win.unmaximize() : win.maximize();
  else if (action === 'close') win.close();
  else return false;
  return true;
});

registerIpcListener('renderer-close-ready', (event) => {
  if (!quitFlushPending || !mainWindow || event.sender !== mainWindow.webContents) return;
  finishCloseAfterRendererFlush();
});

registerIpcListener('mpris-update', (event, payload) => {
  updateMpris(payload);
});

registerIpcHandler('dialog:openFolder', async () => {
  const { canceled, filePaths } = await dialog.showOpenDialog(mainWindow, {
    properties: ['openDirectory']
  });
  if (canceled) {
    return null;
  } else {
    return filePaths[0];
  }
});

registerIpcHandler('get-default-download-folder', () => getDefaultDownloadFolder());

registerIpcHandler('check-ytdlp-tools', async () => {
  const ytdlp = await runProcess('yt-dlp', ['--version'], { timeoutMs: 8000 });
  const ffmpeg = await runProcess('ffmpeg', ['-version'], { timeoutMs: 8000 });
  // `ffmpeg -version` output starts with "ffmpeg version N.N ..." — grab the actual version token
  const ffmpegVersionMatch = (ffmpeg.stdout || '').match(/version\s+(\S+)/);
  return {
    ytdlp: ytdlp.ok ? (ytdlp.stdout || '').trim().split(/\s+/)[0] : '',
    ffmpeg: ffmpeg.ok ? (ffmpegVersionMatch ? ffmpegVersionMatch[1] : 'installed') : '',
    ok: ytdlp.ok && ffmpeg.ok,
    error: !ytdlp.ok ? 'yt-dlp was not found in PATH.' : (!ffmpeg.ok ? 'ffmpeg was not found in PATH.' : '')
  };
});

registerIpcHandler('search-download-candidates', async (event, track, limit, requestId) => {
  try {
    const meta = normalizeImportTrackMeta(track);
    if (!meta.title || !meta.artist) return { ok: false, error: 'Track title and artist are required.', candidates: [] };
    const requestIdSupplied = requestId !== undefined && requestId !== null && String(requestId) !== '';
    requestId = requestIdSupplied ? String(requestId).replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 80) : '';
    if (requestIdSupplied && !requestId) return { ok: false, error: 'Invalid download search request ID.', candidates: [] };
    if (requestId && (reservedDownloadRequestIds.has(requestId) || activeYtdlpDownloads.has(requestId))) {
      return { ok: false, error: 'A download operation with this request ID is already active.', candidates: [] };
    }
    const max = Math.max(1, Math.min(10, parseInt(limit, 10) || 5));
    const cacheKey = getDownloadSearchCacheKey(meta, max);
    const cached = downloadSearchCache.get(cacheKey);
    if (cached && Date.now() - cached.createdAt < DOWNLOAD_SEARCH_CACHE_TTL_MS) return { ...cached.result, cached: true };
    if (!requestId && downloadSearchInFlight.has(cacheKey)) return await downloadSearchInFlight.get(cacheKey);

    const searchPromise = searchDownloadCandidates(meta, max, requestId)
      .then((result) => {
        if (result && result.ok) downloadSearchCache.set(cacheKey, { createdAt: Date.now(), result });
        return result;
      })
      .finally(() => { if (!requestId) downloadSearchInFlight.delete(cacheKey); });
    if (!requestId) downloadSearchInFlight.set(cacheKey, searchPromise);
    return await searchPromise;
  } catch (e) {
    return { ok: false, error: e.message || String(e), candidates: [] };
  }
});

async function searchDownloadCandidates(meta, max, requestId) {
  try {
    const perQuery = Math.max(4, Math.min(5, max));
    const queries = buildDownloadSearchQueries(meta);
    const result = await runProcess('yt-dlp', [
      '--ignore-config',
      '--dump-json',
      '--flat-playlist',
      '--skip-download',
      '--no-playlist',
      ...queries.map(query => `ytsearch${perQuery}:${query}`)
    ], { timeoutMs: 2 * 60 * 1000, processKey: requestId });
    const candidateMap = new Map();
    result.stdout.split(/\r?\n/).map(line => line.trim()).filter(Boolean).forEach((line) => {
      let item = null;
      try { item = JSON.parse(line); }
      catch (e) { return; }
      const thumbnails = Array.isArray(item.thumbnails) ? item.thumbnails : [];
      const bestThumb = thumbnails.length ? thumbnails[thumbnails.length - 1].url : (item.thumbnail || '');
      const candidate = {
        id: item.id || '',
        title: item.title || '',
        uploader: item.uploader || item.channel || '',
        channel: item.channel || item.uploader || '',
        duration: parseDurationSeconds(item.duration || item.duration_string || 0),
        webpageUrl: item.webpage_url || (item.id ? `https://www.youtube.com/watch?v=${item.id}` : (item.original_url || item.url || '')),
        thumbnail: bestThumb || '',
        channelVerified: item.channel_is_verified === true,
      };
      const key = candidate.id || candidate.webpageUrl || normalizeSearchText(`${candidate.title} ${candidate.uploader}`);
      if (!key) return;
      candidate.score = downloadCandidateScore(meta, candidate);
      const existing = candidateMap.get(key);
      if (existing) {
        existing.score = Math.max(existing.score, candidate.score);
        existing.seen = (existing.seen || 1) + 1;
        if (!existing.thumbnail && candidate.thumbnail) existing.thumbnail = candidate.thumbnail;
        if (!existing.duration && candidate.duration) existing.duration = candidate.duration;
      } else {
        candidate.seen = 1;
        candidateMap.set(key, candidate);
      }
    });
    const candidates = Array.from(candidateMap.values()).map((candidate) => {
      if (candidate.seen > 1) candidate.score += Math.min(16, (candidate.seen - 1) * 4);
      candidate.confidence = candidateConfidence(candidate.score);
      return candidate;
    }).sort((a, b) => b.score - a.score).slice(0, max);
    if (result.cancelled) return { ok: false, cancelled: true, error: 'Download candidate search cancelled.', candidates: [] };
    if (!result.ok && !candidates.length) {
      return { ok: false, error: formatYtdlpError(result.stderr || result.stdout, 'yt-dlp search failed.'), candidates: [] };
    }
    return { ok: true, queries, candidates };
  } catch (e) {
    return { ok: false, error: e.message || String(e), candidates: [] };
  }
}

function getSafeYtdlpDownloadSource(meta) {
  if (!meta.downloadUrl) {
    const query = buildDownloadSearchQueries(meta)[0] || `${meta.artist} ${meta.title}`;
    return `ytsearch1:${query.replace(/[\u0000-\u001f\u007f]/g, ' ').slice(0, 1000)}`;
  }
  try {
    const parsed = new URL(String(meta.downloadUrl));
    const host = parsed.hostname.toLowerCase();
    if (parsed.protocol !== 'https:' || parsed.username || parsed.password) return '';
    if (!['youtube.com', 'www.youtube.com', 'music.youtube.com', 'youtu.be'].includes(host)) return '';
    return parsed.href.slice(0, 2000);
  } catch (e) {
    return '';
  }
}

registerIpcHandler('download-playlist-track', async (event, track, downloadRoot, requestId) => {
  const reservedHere = [];
  let tempDir = '';
  let finalizedPath = '';
  try {
    if (backupRestoreInProgress) return { ok: false, error: 'A backup restore is in progress.' };
    const meta = normalizeImportTrackMeta(track);
    if (!meta.title || !meta.artist) return { ok: false, error: 'Track title and artist are required.' };
    requestId = String(requestId || '').replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 80);
    if (!requestId) return { ok: false, error: 'Invalid download request ID.' };
    if (reservedDownloadRequestIds.has(requestId) || activeYtdlpDownloads.has(requestId)) return { ok: false, error: 'A download with this request ID is already active.' };
    reservedDownloadRequestIds.add(requestId);
    const source = getSafeYtdlpDownloadSource(meta);
    if (!source) return { ok: false, error: 'Only HTTPS YouTube download URLs are supported.' };
    const rootInput = normalizePathInput(downloadRoot) || getDefaultDownloadFolder();
    if (!path.isAbsolute(rootInput)) return { ok: false, error: 'Download folder must be an absolute path.' };
    const root = path.resolve(rootInput);
    await fs.promises.mkdir(root, { recursive: true });
    await ensureSafeDownloadDirectory(root, root);
    const tempRoot = path.join(root, '.downloading');
    await ensureSafeDownloadDirectory(root, tempRoot);
    cleanupStaleDownloadTempDirs(root).catch(() => { });
    let targetPath = await ensureUniquePath(buildDownloadTargetPath(track, root), reservedDownloadPaths);
    reservedDownloadPaths.add(targetPath); reservedHere.push(targetPath);
    const albumDir = path.dirname(targetPath);
    let albumDirWasMissing = false;
    try { await fs.promises.lstat(albumDir); }
    catch (e) { if (e.code === 'ENOENT') albumDirWasMissing = true; else throw e; }
    await ensureSafeDownloadDirectory(root, albumDir);
    if (albumDirWasMissing) downloadCreatedAlbumDirs.add(albumDir);

    tempDir = path.join(tempRoot, `${Date.now()}-${crypto.randomBytes(4).toString('hex')}`);
    await ensureSafeDownloadDirectory(root, tempDir);
    const args = [
      '--ignore-config',
      '--no-playlist',
      '--format', 'bestaudio/best',
      '--extract-audio',
      '--audio-format', 'mp3',
      '--audio-quality', '320K',
      '--output', path.join(tempDir, 'download.%(ext)s'),
      ...getYtdlpAuthArgs(),
      '--',
      source
    ];
    const sendProgress = (chunk) => {
      if (!requestId || !event.sender || event.sender.isDestroyed()) return;
      const matches = String(chunk || '').matchAll(/\[download\]\s+(\d+(?:\.\d+)?)%/g);
      let last = null;
      for (const match of matches) last = Number(match[1]);
      if (last !== null && !Number.isNaN(last)) {
        try { event.sender.send('download-progress', { requestId, percent: last }); } catch (_) { }
      }
    };
    const result = await runProcess('yt-dlp', args, { timeoutMs: 10 * 60 * 1000, processKey: requestId, onStdout: sendProgress, onStderr: sendProgress });
    if (result.cancelled) {
      try { await fs.promises.rm(tempDir, { recursive: true, force: true }); } catch (e) { }
      return { ok: false, cancelled: true, error: 'Download cancelled.' };
    }
    if (!result.ok) {
      try { await fs.promises.rm(tempDir, { recursive: true, force: true }); } catch (e) { }
      return { ok: false, error: formatYtdlpError(result.stderr || result.stdout, 'yt-dlp failed.'), ageRestricted: isYtdlpAgeRestrictedError(result.stderr || result.stdout) };
    }

    const tempFiles = await fs.promises.readdir(tempDir, { withFileTypes: true });
    const mp3 = tempFiles.find(file => file.isFile() && !file.isSymbolicLink() && path.extname(file.name).toLowerCase() === '.mp3');
    if (!mp3) {
      try { await fs.promises.rm(tempDir, { recursive: true, force: true }); } catch (e) { }
      return { ok: false, error: 'yt-dlp finished, but no MP3 file was created.' };
    }
    const downloadedFile = path.join(tempDir, mp3.name);
    while (true) {
      try {
        await ensureSafeDownloadDirectory(root, path.dirname(targetPath));
        await finalizeDownloadedFile(downloadedFile, targetPath);
        finalizedPath = targetPath;
        break;
      } catch (e) {
        if (e.code !== 'EEXIST') throw e;
        targetPath = await ensureUniquePath(targetPath, reservedDownloadPaths);
        reservedDownloadPaths.add(targetPath); reservedHere.push(targetPath);
      }
    }
    try { await fs.promises.rm(tempDir, { recursive: true, force: true }); } catch (e) { }

    await writeDownloadedMp3Metadata(targetPath, track, downloadCreatedAlbumDirs.has(albumDir));
    const libraryItem = await buildLibraryItemFromAudioFile(targetPath);
    if (!libraryItem) throw new Error('Downloaded file metadata could not be added to the library');
    if (requestId && event.sender && !event.sender.isDestroyed()) {
      try { event.sender.send('download-progress', { requestId, percent: 100 }); } catch (_) { }
    }
    return { ok: true, filePath: targetPath, libraryItem, targetPath };
  } catch (e) {
    if (finalizedPath) await fs.promises.rm(finalizedPath, { force: true }).catch((cleanupError) => console.error('Could not remove failed finalized download:', cleanupError));
    return { ok: false, error: e.message || String(e) };
  } finally {
    if (tempDir) await fs.promises.rm(tempDir, { recursive: true, force: true }).catch(() => { });
    for (const p of reservedHere) reservedDownloadPaths.delete(p);
    if (requestId) reservedDownloadRequestIds.delete(requestId);
  }
});

registerIpcHandler('cancel-download', async (event, requestId) => {
  requestId = String(requestId || '').replace(/[^a-zA-Z0-9_-]/g, '').slice(0, 80);
  if (!requestId) return false;
  const child = activeYtdlpDownloads.get(requestId);
  if (!child) return false;
  cancelledYtdlpDownloads.add(requestId);
  try {
    if (child.kill('SIGTERM')) return true;
  } catch (e) { }
  cancelledYtdlpDownloads.delete(requestId);
  return false;
});

// IPC Handler: Open File (CSV)
registerIpcHandler('dialog:openFile', async () => {
  const { canceled, filePaths } = await dialog.showOpenDialog(mainWindow, {
    properties: ['openFile'],
    filters: [{ name: 'CSV Files', extensions: ['csv'] }]
  });
  if (canceled) {
    return null;
  } else {
    return filePaths[0];
  }
});

registerIpcHandler('dialog:openCookiesFile', async () => {
  const { canceled, filePaths } = await dialog.showOpenDialog(mainWindow, {
    properties: ['openFile'],
    filters: [
      { name: 'Cookies', extensions: ['txt'] },
      { name: 'All Files', extensions: ['*'] }
    ]
  });
  return canceled ? null : filePaths[0];
});

// IPC Handler: Open Image File (for custom playlist cover)
registerIpcHandler('dialog:openImage', async () => {
  const { canceled, filePaths } = await dialog.showOpenDialog(mainWindow, {
    properties: ['openFile'],
    filters: [{ name: 'Images', extensions: ['jpg', 'jpeg', 'png', 'bmp', 'webp', 'tiff', 'tif', 'gif', 'avif'] }]
  });
  return canceled ? null : getSafeFileUrl(filePaths[0]);
});

// IPC Handler: Open Audio File (for manual match)
registerIpcHandler('dialog:openAudio', async () => {
  const { canceled, filePaths } = await dialog.showOpenDialog(mainWindow, {
    properties: ['openFile'],
    filters: [{ name: 'Audio', extensions: ['mp3', 'wav', 'flac', 'm4a'] }]
  });
  return canceled ? null : filePaths[0];
});

registerIpcHandler('scan-audio-file', async (event, filePath) => {
  filePath = normalizePathInput(filePath);
  if (!isExistingFileWithExt(filePath, AUDIO_EXTENSIONS)) return null;
  try {
    const item = await buildLibraryItemFromAudioFile(filePath);
    if (item) item.addedAtMs = Date.now();
    return item;
  }
  catch (e) { console.error('Failed to scan audio file:', e); return null; }
});

async function walkDir(dir, supportedExtensions, fileList, failures) {
  let files;
  try {
    files = await fs.promises.readdir(dir, { withFileTypes: true });
  } catch (e) {
    if (e && (e.code === 'ENOENT' || e.code === 'ENOTDIR')) {
      console.warn('Skipping missing directory:', dir);
    } else {
      console.error('Error reading directory', dir, e);
    }
    if (failures && failures.length < 100) failures.push({ path: dir, error: e && (e.code || e.message) ? (e.code || e.message) : String(e) });
    return;
  }
  for (const file of files) {
    const fullPath = path.join(dir, file.name);
    if (file.isDirectory()) {
      await walkDir(fullPath, supportedExtensions, fileList, failures);
    } else {
      const ext = path.extname(file.name).toLowerCase();
      if (supportedExtensions.includes(ext)) {
        if (fileList.length >= MAX_SCAN_AUDIO_FILES) {
          const error = new Error(`Folder contains more than the ${MAX_SCAN_AUDIO_FILES} audio-file scan limit`);
          error.code = 'AUDIO_SCAN_LIMIT';
          throw error;
        }
        fileList.push(fullPath);
      }
    }
  }
}

function isPathWithin(candidate, parent) {
  const relative = path.relative(path.resolve(parent), path.resolve(candidate));
  return relative === '' || (!relative.startsWith('..' + path.sep) && relative !== '..' && !path.isAbsolute(relative));
}

function sendScanProgress(event, payload) {
  try {
    if (event.sender && !event.sender.isDestroyed()) event.sender.send('scan-progress', payload);
  } catch (_) { }
}

function finishFolderScan(event, files, failures, totalFiles) {
  const warnings = failures.slice(0, 100).map(failure => `${failure.path}: ${failure.error}`);
  files.warnings = warnings;
  files.partial = failures.length > 0;
  if (failures.length) {
    sendScanProgress(event, { current: totalFiles, total: totalFiles, partial: true, warnings });
    const details = warnings.slice(0, 8).map(warning => `- ${warning}`).join('\n');
    const more = failures.length > 8 ? `\n...and ${failures.length - 8} more.` : '';
    const options = {
      type: 'warning',
      title: 'Library Scan Incomplete',
      message: 'Some folders or files could not be scanned. Existing library entries were preserved.',
      detail: details + more,
    };
    const message = mainWindow && !mainWindow.isDestroyed() ? dialog.showMessageBox(mainWindow, options) : dialog.showMessageBox(options);
    message.catch((e) => console.warn('Could not show scan warning:', e));
  }
  return files;
}

const folderCoverCache = new Map();

async function findFallbackCover(dirPath) {
  if (folderCoverCache.has(dirPath)) return folderCoverCache.get(dirPath);
  // Priority names first, then any image in folder
  const priorityNames = [
    'folder.jpg', 'folder.jpeg', 'cover.jpg', 'cover.jpeg', 'front.jpg', 'front.jpeg',
    'folder.png', 'cover.png', 'folder.bmp', 'cover.bmp', 'folder.webp', 'cover.webp'
  ];
  const extensions = ['.jpg', '.jpeg', '.png', '.bmp', '.webp', '.tiff', '.tif', '.gif', '.avif'];
  try {
    const files = await fs.promises.readdir(dirPath);
    const filesLower = files.map(f => f.toLowerCase());
    // Check priority names first
    for (const name of priorityNames) {
      const idx = filesLower.indexOf(name);
      if (idx !== -1) {
        const coverPath = path.join(dirPath, files[idx]);
        const fileUrl = getSafeFileUrl(coverPath);
        folderCoverCache.set(dirPath, fileUrl);
        return fileUrl;
      }
    }
    // Then any image
    for (const file of files) {
      if (extensions.includes(path.extname(file).toLowerCase())) {
        const coverPath = path.join(dirPath, file);
        const fileUrl = getSafeFileUrl(coverPath);
        folderCoverCache.set(dirPath, fileUrl);
        return fileUrl;
      }
    }
  } catch (e) {
    folderCoverCache.set(dirPath, null);
    return null;
  }
  folderCoverCache.set(dirPath, null);
  return null;
}

const LIBRARY_FILE = path.join(app.getPath('userData'), 'library.json');
const PLAYLISTS_FILE = path.join(app.getPath('userData'), 'playlists.json');
const MAPPINGS_FILE = path.join(app.getPath('userData'), 'mappings.json');
const SETTINGS_FILE = path.join(app.getPath('userData'), 'settings.json');
const LIKED_SONGS_FILE = path.join(app.getPath('userData'), 'liked-songs.json');
const RESTORE_MANIFEST_FILE = path.join(app.getPath('userData'), '.backup-restore-transaction.json');
const COVERS_DIR = path.join(app.getPath('userData'), 'covers');

if (!fs.existsSync(COVERS_DIR)) {
  fs.mkdirSync(COVERS_DIR, { recursive: true });
}

function getDefaultDownloadFolder() {
  let musicDir = '';
  try { musicDir = app.getPath('music'); }
  catch (e) { musicDir = app.getPath('home'); }
  return path.join(musicDir || app.getPath('home'), `${APP_NAME} Downloads`);
}

function sanitizePathSegment(value, fallback) {
  let s = String(value || '').trim();
  if (!s) s = fallback || 'Unknown';
  s = s.replace(/[<>:"/\\|?*\x00-\x1F]/g, ' ').replace(/\s+/g, ' ').trim();
  s = s.replace(/[. ]+$/g, '');
  if (!s) s = fallback || 'Unknown';
  return s.slice(0, 110);
}

function parseTrackNumber(value) {
  if (value === null || value === undefined) return 0;
  const match = String(value).match(/\d+/);
  return match ? parseInt(match[0], 10) || 0 : 0;
}

function parseDurationSeconds(value) {
  if (value === null || value === undefined || value === '') return 0;
  if (typeof value === 'number') return value > 1000 ? Math.round(value / 1000) : value;
  const s = String(value).trim();
  if (/^\d+(?:\.\d+)?$/.test(s)) {
    const n = parseFloat(s);
    return n > 1000 ? Math.round(n / 1000) : n;
  }
  const parts = s.split(':').map(part => parseFloat(part) || 0);
  if (parts.length === 2) return parts[0] * 60 + parts[1];
  if (parts.length === 3) return parts[0] * 3600 + parts[1] * 60 + parts[2];
  return 0;
}

function normalizeSearchText(value) {
  return String(value || '')
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .replace(/\([^)]*\)|\[[^\]]*\]/g, ' ')
    .replace(/[^a-z0-9]+/g, ' ')
    .trim();
}

function searchTokens(value) {
  return normalizeSearchText(value).split(/\s+/).filter(token => token.length > 2);
}

function tokenCoverage(tokens, text) {
  if (!tokens.length) return 0;
  const hit = tokens.filter(token => text.includes(token)).length;
  return hit / tokens.length;
}

function searchArtistVariants(value) {
  const normalized = String(value || '')
    .replace(/\b(feat\.?|featuring|ft\.?|with)\b/ig, ',')
    .split(/,|&|\+/)
    .map(part => searchTokens(part))
    .filter(tokens => tokens.length);
  return normalized.length ? normalized : [searchTokens(value)].filter(tokens => tokens.length);
}

function bestTokenCoverage(tokenGroups, text) {
  return tokenGroups.reduce((best, tokens) => Math.max(best, tokenCoverage(tokens, text)), 0);
}

function formatYtdlpError(raw, fallback) {
  const text = String(raw || '').trim();
  if (!text) return fallback;
  if (isYtdlpAgeRestrictedError(text)) {
    return 'YouTube requires sign-in/age confirmation for this video. Pick another candidate, or enable YouTube cookies in Settings.';
  }
  return text.split(/\r?\n/).map(line => line.trim()).filter(Boolean).slice(-3).join('\n').slice(0, 600) || fallback;
}

function isYtdlpAgeRestrictedError(raw) {
  return /sign in to confirm your age|inappropriate for some users|cookies-from-browser|pass cookies/i.test(String(raw || ''));
}

function getYtdlpAuthArgs() {
  const mode = appSettings.ytdlCookiesMode || 'none';
  if (mode === 'browser') {
    const allowed = new Set(['firefox', 'chrome', 'chromium', 'brave', 'edge', 'vivaldi', 'opera']);
    const browser = allowed.has(appSettings.ytdlCookiesBrowser) ? appSettings.ytdlCookiesBrowser : 'firefox';
    return ['--cookies-from-browser', browser];
  }
  if (mode === 'file') {
    const cookiePath = normalizePathInput(appSettings.ytdlCookiesFile || '');
    if (cookiePath && path.isAbsolute(cookiePath) && isExistingFileWithExt(cookiePath, ['.txt'])) return ['--cookies', cookiePath];
  }
  return [];
}

function getDownloadSearchCacheKey(meta, max) {
  return [
    normalizeSearchText(meta.title),
    normalizeSearchText(meta.artist),
    normalizeSearchText(meta.album),
    Math.round(Number(meta.duration || 0)),
    max,
  ].join('|');
}

function buildDownloadSearchQueries(meta) {
  const title = String(meta.title || '').trim();
  const artist = String(meta.artist || '').trim();
  const album = String(meta.album || '').trim();
  const queries = [
    `"${title}" "${artist}"`,
    `${artist} ${title}`,
    `${title} ${artist} topic`,
  ];
  if (album) queries.push(`${title} ${artist} ${album}`);
  queries.push(`${artist} ${title} official audio`);
  return Array.from(new Set(queries.map(q => q.replace(/\s+/g, ' ').trim()).filter(Boolean)));
}

function downloadCandidateScore(meta, candidate) {
  const expectedTitle = normalizeSearchText(meta.title);
  const expectedArtist = normalizeSearchText(meta.artist);
  const expectedAlbum = normalizeSearchText(meta.album);
  const titleTokens = searchTokens(meta.title);
  const artistGroups = searchArtistVariants(meta.artist);
  const title = normalizeSearchText(candidate.title || '');
  const uploader = normalizeSearchText(candidate.uploader || candidate.channel || '');
  const combined = `${title} ${uploader}`;
  const titleCoverage = tokenCoverage(titleTokens, title);
  const uploaderArtistCoverage = bestTokenCoverage(artistGroups, uploader);
  const titleArtistCoverage = bestTokenCoverage(artistGroups, title);
  const combinedArtistCoverage = bestTokenCoverage(artistGroups, combined);
  let score = 0;

  if (expectedTitle && title.includes(expectedTitle)) score += 58;
  else score += Math.round(titleCoverage * 34);

  if (expectedArtist && uploader.includes(expectedArtist)) score += 48;
  else score += Math.round(uploaderArtistCoverage * 44);
  if (!(expectedArtist && uploader.includes(expectedArtist)) && titleArtistCoverage >= 0.8) score += 12;
  else if (titleArtistCoverage >= 0.5) score += 6;

  if (expectedAlbum && combined.includes(expectedAlbum)) score += 8;
  if (/\btopic\b/.test(uploader) && uploaderArtistCoverage >= 0.8) score += 22;
  if (candidate.channelVerified && uploaderArtistCoverage >= 0.8) score += 6;
  if (/official audio|provided to youtube|auto generated|audio only/i.test(candidate.title || '')) score += 8;
  if (/official/i.test(candidate.uploader || candidate.channel || '')) score += 3;
  if (titleCoverage < 0.5) score -= 28;
  if (artistGroups.length && uploaderArtistCoverage < 0.45) score -= titleArtistCoverage >= 0.8 ? 34 : 26;
  if (artistGroups.length && combinedArtistCoverage < 0.45) score -= 14;
  if (/live|slowed|nightcore|sped up|remix|cover|karaoke|instrumental|sound effect|sfx|tutorial|photoshop|scam|compilation|mix -/i.test(candidate.title || '')) score -= 28;
  if (/sound effect|sfx|audio library|piximperfect/i.test(candidate.uploader || candidate.channel || '')) score -= 22;
  if (meta.duration && candidate.duration) {
    const diff = Math.abs(Number(candidate.duration) - Number(meta.duration));
    if (diff <= 3) score += 20;
    else if (diff <= 8) score += 12;
    else if (diff <= 20) score += 4;
    else score -= 18;
  }
  return score;
}

function candidateConfidence(score) {
  if (score >= 70) return 'high';
  if (score >= 45) return 'medium';
  return 'low';
}

function normalizeImportTrackMeta(track) {
  track = track && typeof track === 'object' ? track : {};
  const title = track.title || track.Song || track.song || track.Name || track.name || track.TITLE || '';
  const artist = track.artist || track.Artist || track.ARTIST || '';
  const album = track.album || track.Album || track.ALBUM || '';
  const albumArtist = track.albumArtist || track.AlbumArtist || track['Album Artist'] || track.Album_Artist || '';
  const albumDate = track.albumDate || track['Album Date'] || track.AlbumDate || track.Year || track.year || '';
  const genre = track.genre || track.Genres || track.Genre || track.GENRE || '';
  const duration = parseDurationSeconds(track.duration || track.Duration || track.DURATION || '');
  const trackNo = parseTrackNumber(track.trackNo || track.TrackNo || track['Track No'] || track.TrackNumber || track['Track Number']);
  const discNo = parseTrackNumber(track.discNo || track.DiscNo || track['Disc No'] || track.DiscNumber || track['Disc Number']);
  const coverUrl = track.coverUrl || track.CoverUrl || track.Cover || track.Image || track.Artwork || track.thumbnailUrl || track.thumbnail || track.downloadThumbnail || '';
  const spotifyTrackId = track.spotifyTrackId || track['Spotify Track Id'] || track.SpotifyTrackId || '';
  const isrc = track.isrc || track.ISRC || '';
  const downloadUrl = track.downloadUrl || track.webpageUrl || track.webpage_url || track.url || '';
  return { title, artist, album, albumArtist, albumDate, genre, duration, trackNo, discNo, coverUrl, spotifyTrackId, isrc, downloadUrl };
}

function buildDownloadTargetPath(track, rootFolder) {
  const meta = normalizeImportTrackMeta(track);
  const root = normalizePathInput(rootFolder) || getDefaultDownloadFolder();
  if (!path.isAbsolute(root)) throw new Error('Download folder must be an absolute path');
  const artistFolder = sanitizePathSegment(meta.albumArtist || meta.artist, 'Unknown Artist');
  const albumFolder = sanitizePathSegment(meta.album || 'Singles', 'Singles');
  const title = sanitizePathSegment(meta.title, 'Unknown Track');
  const prefix = meta.trackNo ? String(meta.trackNo).padStart(2, '0') + ' - ' : '';
  return path.join(root, artistFolder, albumFolder, `${prefix}${title}.mp3`);
}

// Paths picked as download targets but not created on disk yet; keeps two
// concurrent downloads of the same track from resolving to the same file.
const reservedDownloadPaths = new Set();
const downloadCreatedAlbumDirs = new Set();

async function ensureUniquePath(filePath, extraTaken) {
  const taken = (p) => fs.existsSync(p) || (extraTaken && extraTaken.has(p));
  if (!taken(filePath)) return filePath;
  const dir = path.dirname(filePath);
  const ext = path.extname(filePath);
  const base = path.basename(filePath, ext);
  for (let i = 2; i < 1000; i++) {
    const candidate = path.join(dir, `${base} (${i})${ext}`);
    if (!taken(candidate)) return candidate;
  }
  throw new Error('Could not create a unique file path');
}

async function ensureSafeDownloadDirectory(root, targetDir) {
  const resolvedRoot = path.resolve(root);
  const resolvedTarget = path.resolve(targetDir);
  const relative = path.relative(resolvedRoot, resolvedTarget);
  if (relative.startsWith('..' + path.sep) || relative === '..' || path.isAbsolute(relative)) throw new Error('Download target escapes the selected folder');
  let current = resolvedRoot;
  const parts = relative ? relative.split(path.sep).filter(Boolean) : [];
  const rootStat = await fs.promises.lstat(current);
  if (!rootStat.isDirectory() || rootStat.isSymbolicLink()) throw new Error('Download root must be a real directory, not a symbolic link');
  for (const part of parts) {
    current = path.join(current, part);
    try { await fs.promises.mkdir(current, { mode: 0o700 }); }
    catch (e) { if (e.code !== 'EEXIST') throw e; }
    const stat = await fs.promises.lstat(current);
    if (!stat.isDirectory() || stat.isSymbolicLink()) throw new Error(`Unsafe symbolic link or non-directory in download path: ${current}`);
  }
  return resolvedTarget;
}

async function finalizeDownloadedFile(sourcePath, targetPath) {
  const sourceStat = await fs.promises.lstat(sourcePath);
  if (!sourceStat.isFile() || sourceStat.isSymbolicLink()) throw new Error('Downloaded output is not a regular file');
  if (sourceStat.size > MAX_DOWNLOADED_AUDIO_BYTES) throw new Error('Downloaded MP3 exceeds the 512 MB output limit');
  let linkError = null;
  try {
    await fs.promises.link(sourcePath, targetPath);
  } catch (e) {
    if (e.code === 'EEXIST') throw e;
    linkError = e;
    try { await fs.promises.copyFile(sourcePath, targetPath, fs.constants.COPYFILE_EXCL); }
    catch (copyError) {
      if (copyError.code === 'EEXIST') throw copyError;
      await fs.promises.rm(targetPath, { force: true }).catch(() => { });
      throw new Error(`Could not finalize download (link: ${linkError.message || linkError}; copy: ${copyError.message || copyError})`);
    }
  }
  await fs.promises.unlink(sourcePath).catch((e) => console.warn('Could not remove finalized download temp file:', e));
}

// Remove .downloading temp dirs left behind by a crash (dir names start with a timestamp)
async function cleanupStaleDownloadTempDirs(root) {
  const base = path.join(root, '.downloading');
  try {
    const baseStat = await fs.promises.lstat(base);
    if (!baseStat.isDirectory() || baseStat.isSymbolicLink()) return;
  } catch (e) { return; }
  let entries;
  try { entries = await fs.promises.readdir(base, { withFileTypes: true }); } catch (e) { return; }
  const cutoff = Date.now() - 60 * 60 * 1000; // downloads time out after 10 min; 1h is safely stale
  for (const entry of entries) {
    const match = entry.name.match(/^(\d{13})-([0-9a-f]{8})$/);
    if (!match || !entry.isDirectory() || entry.isSymbolicLink()) continue;
    const full = path.join(base, entry.name);
    try {
      const stat = await fs.promises.lstat(full);
      const createdAt = Number(match[1]);
      if (stat.isDirectory() && !stat.isSymbolicLink() && createdAt < cutoff) await fs.promises.rm(full, { recursive: true, force: true });
    } catch (e) { }
  }
}

function runProcess(command, args, options = {}) {
  return new Promise((resolve) => {
    const child = spawn(command, args, { cwd: options.cwd || undefined, shell: false, windowsHide: true });
    const processKey = options.processKey || '';
    if (processKey) activeYtdlpDownloads.set(processKey, child);
    let stdout = '';
    let stderr = '';
    const maxOutputChars = Math.max(1024, options.maxOutputChars || 8 * 1024 * 1024);
    let settled = false;
    let timedOut = false;
    const timeoutMs = options.timeoutMs || 0;
    const cleanup = () => {
      if (processKey && activeYtdlpDownloads.get(processKey) === child) activeYtdlpDownloads.delete(processKey);
    };
    let timer = null;
    let forceKillTimer = null;
    const clearTimers = () => {
      if (timer) clearTimeout(timer);
      if (forceKillTimer) clearTimeout(forceKillTimer);
    };
    if (timeoutMs > 0) {
      timer = setTimeout(() => {
        if (settled) return;
        timedOut = true;
        try { child.kill('SIGTERM'); } catch (e) { }
        forceKillTimer = setTimeout(() => {
          if (settled) return;
          try { child.kill('SIGKILL'); } catch (e) { }
        }, 3000);
        forceKillTimer.unref();
      }, timeoutMs);
    }
    child.stdout.on('data', (d) => { const s = d.toString(); if (stdout.length < maxOutputChars) stdout += s.slice(0, maxOutputChars - stdout.length); if (options.onStdout) options.onStdout(s); });
    child.stderr.on('data', (d) => { const s = d.toString(); if (stderr.length < maxOutputChars) stderr += s.slice(0, maxOutputChars - stderr.length); if (options.onStderr) options.onStderr(s); });
    child.on('error', (err) => {
      if (settled) return;
      settled = true;
      clearTimers();
      cleanup();
      if (processKey && cancelledYtdlpDownloads.delete(processKey)) {
        resolve({ ok: false, cancelled: true, code: -1, stdout, stderr: stderr || 'Cancelled' });
        return;
      }
      resolve({ ok: false, timedOut, code: -1, stdout, stderr: timedOut ? (stderr || 'Timed out') : (err.message || String(err)), error: err });
    });
    child.on('close', (code) => {
      if (settled) return;
      settled = true;
      clearTimers();
      cleanup();
      if (processKey && cancelledYtdlpDownloads.delete(processKey)) {
        resolve({ ok: false, cancelled: true, code, stdout, stderr: stderr || 'Cancelled' });
        return;
      }
      if (timedOut) {
        resolve({ ok: false, timedOut: true, code, stdout, stderr: stderr || 'Timed out' });
        return;
      }
      resolve({ ok: code === 0, code, stdout, stderr });
    });
  });
}

async function writeDownloadedMp3Metadata(filePath, track, createFolderCover) {
  const meta = normalizeImportTrackMeta(track);
  const tags = {};
  const fileStat = await fs.promises.stat(filePath);
  if (!fileStat.isFile() || fileStat.size > MAX_METADATA_EDIT_BYTES) throw new Error('Downloaded MP3 is too large for metadata editing');
  let folderCover = null;
  if (meta.title) tags.title = meta.title;
  if (meta.artist) tags.artist = meta.artist;
  if (meta.album) tags.album = meta.album;
  if (meta.albumArtist) tags.performerInfo = meta.albumArtist;
  if (meta.albumDate) tags.year = String(meta.albumDate).slice(0, 4);
  if (meta.genre) tags.genre = meta.genre;
  if (meta.trackNo) tags.trackNumber = String(meta.trackNo);
  if (meta.discNo) tags.partOfSet = String(meta.discNo);
  if (meta.coverUrl && /^https:\/\//i.test(meta.coverUrl)) {
    try {
      const cover = await fetchCachedCoverImage(meta.coverUrl);
      tags.image = {
        mime: cover.contentType.split(';')[0].trim().toLowerCase(),
        type: { id: 3, name: 'front cover' },
        description: '',
        imageBuffer: cover.imageBuffer,
      };
      if (createFolderCover && ['image/jpeg', 'image/jpg'].includes(tags.image.mime)) folderCover = cover.imageBuffer;
    } catch (e) {
      console.error('Failed to fetch downloaded track cover:', e);
    }
  }
  if (Object.keys(tags).length) {
    const result = NodeID3.update(tags, filePath);
    if (result !== true) throw (result instanceof Error ? result : new Error('MP3 metadata writer returned an invalid result'));
    const updatedStat = await fs.promises.stat(filePath);
    if (!updatedStat.isFile() || updatedStat.size > MAX_DOWNLOADED_AUDIO_BYTES) throw new Error('Downloaded MP3 exceeds the 512 MB output limit after metadata editing');
  }
  if (folderCover) {
    try { await fs.promises.writeFile(path.join(path.dirname(filePath), 'folder.jpg'), folderCover, { flag: 'wx' }); }
    catch (e) { if (e.code !== 'EEXIST') console.error('Failed to write downloaded folder.jpg:', e); }
  }
}

async function buildLibraryItemFromAudioFile(filePath, fileStat) {
  filePath = normalizePathInput(filePath);
  if (!isExistingFileWithExt(filePath, AUDIO_EXTENSIONS)) return null;
  if (!fileStat) fileStat = await fs.promises.stat(filePath);
  const filename = path.basename(filePath);
  const dirPath = path.dirname(filePath);
  try {
    const metadata = await mm.parseFile(filePath);
    const rg = getReplayGainFields(metadata);
    const albumName = metadata.common.album || 'Unknown Album';
    const artistName = metadata.common.artist || 'Unknown Artist';
    const albumArtistName = metadata.common.albumartist || (metadata.common.compilation ? 'Various Artists' : null);
    let pictureDataUrl = await findFallbackCover(dirPath);
    if (!pictureDataUrl && metadata.common.picture && metadata.common.picture.length > 0) {
      const coverHash = crypto.createHash('md5').update(albumName + (albumArtistName || artistName)).digest('hex');
      const coverFilePath = path.join(COVERS_DIR, `${coverHash}.jpg`);
      if (!fs.existsSync(coverFilePath)) await fs.promises.writeFile(coverFilePath, metadata.common.picture[0].data);
      pictureDataUrl = getSafeFileUrl(coverFilePath);
    }
    return {
      filePath,
      filename,
      title: metadata.common.title || path.parse(filename).name,
      artist: artistName,
      albumArtist: albumArtistName,
      album: albumName,
      duration: metadata.format.duration || 0,
      picture: pictureDataUrl,
      trackNo: (metadata.common.track && metadata.common.track.no) ? metadata.common.track.no : 0,
      trackTotal: (metadata.common.track && metadata.common.track.of) ? metadata.common.track.of : 0,
      discNo: (metadata.common.disk && metadata.common.disk.no) ? metadata.common.disk.no : 0,
      discTotal: (metadata.common.disk && metadata.common.disk.of) ? metadata.common.disk.of : 0,
      year: metadata.common.year || null,
      genre: metadata.common.genre ? metadata.common.genre[0] : null,
      replayGainTrackDb: rg.replayGainTrackDb,
      replayGainAlbumDb: rg.replayGainAlbumDb,
      replayGainTrackPeak: rg.replayGainTrackPeak,
      replayGainAlbumPeak: rg.replayGainAlbumPeak,
      fileSize: fileStat.size,
      modifiedAtMs: fileStat.mtimeMs,
      addedAtMs: fileStat.mtimeMs,
    };
  } catch (e) {
    return {
      filePath,
      filename,
      title: path.parse(filename).name,
      artist: 'Unknown Artist',
      albumArtist: null,
      album: 'Unknown Album',
      duration: 0,
      picture: await findFallbackCover(dirPath),
      trackNo: 0,
      trackTotal: 0,
      discNo: 0,
      discTotal: 0,
      year: null,
      genre: null,
      replayGainTrackDb: null,
      replayGainAlbumDb: null,
      replayGainTrackPeak: null,
      replayGainAlbumPeak: null,
      fileSize: fileStat.size,
      modifiedAtMs: fileStat.mtimeMs,
      addedAtMs: fileStat.mtimeMs,
    };
  }
}

let settingsLoadError = null;
function loadSettingsFromDisk() {
  try {
    if (fs.existsSync(SETTINGS_FILE)) {
      const settings = readAppDataFile(SETTINGS_FILE, {}, 'settings.json', (value) => {
        if (!isPlainObject(value)) throw new Error('expected an object');
      });
      appSettings = { ...appSettings, ...deserializeSettingsFromDisk(settings) };
    }
    settingsLoadError = null;
  } catch (e) {
    settingsLoadError = e;
    console.error(e);
  }
  return appSettings;
}

function getSafeFileUrl(absolutePath) {
  return pathToFileURL(absolutePath).href;
}

function normalizePathInput(value) {
  if (typeof value !== 'string') return '';
  if (value.startsWith('file://')) {
    try { return fileURLToPath(value); }
    catch (e) { return ''; }
  }
  return value;
}

function isExistingDirectory(dirPath) {
  dirPath = normalizePathInput(dirPath);
  if (typeof dirPath !== 'string' || !path.isAbsolute(dirPath)) return false;
  try { return fs.statSync(dirPath).isDirectory(); }
  catch (e) { return false; }
}

function isExistingFileWithExt(filePath, extensions) {
  filePath = normalizePathInput(filePath);
  if (typeof filePath !== 'string' || !path.isAbsolute(filePath)) return false;
  if (!extensions.includes(path.extname(filePath).toLowerCase())) return false;
  try { return fs.statSync(filePath).isFile(); }
  catch (e) { return false; }
}

function isAllowedImageUrl(value) {
  try {
    const parsed = new URL(String(value || ''));
    const host = parsed.hostname.toLowerCase();
    return parsed.protocol === 'https:'
      && !parsed.username
      && !parsed.password
      && (IMAGE_URL_HOSTS.has(host) || host.endsWith('.archive.org') || host.endsWith('.mzstatic.com') || host.endsWith('.dzcdn.net'));
  } catch (e) {
    return false;
  }
}

async function fetchAllowedImage(url, headers) {
  let currentUrl = String(url || '');
  for (let redirects = 0; redirects <= 4; redirects++) {
    if (!isAllowedImageUrl(currentUrl)) throw new Error('Unapproved image host');
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), 15000);
    try {
      const res = await fetch(currentUrl, { headers, redirect: 'manual', signal: controller.signal });
      if (res.status >= 300 && res.status < 400) {
        const location = res.headers.get('location');
        if (!location) throw new Error('Image redirect has no location');
        currentUrl = new URL(location, currentUrl).href;
        continue;
      }
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const contentType = res.headers.get('content-type') || '';
      if (!contentType.toLowerCase().startsWith('image/')) throw new Error(`not an image: ${contentType}`);
      const declaredSize = Number(res.headers.get('content-length') || 0);
      if (declaredSize > MAX_IMAGE_BYTES) throw new Error('Image is too large');
      if (!res.body) throw new Error('Image response has no body');
      const chunks = [];
      let total = 0;
      for await (const chunk of res.body) {
        total += chunk.length;
        if (total > MAX_IMAGE_BYTES) throw new Error('Image is too large');
        chunks.push(Buffer.from(chunk));
      }
      return { imageBuffer: Buffer.concat(chunks, total), contentType };
    } finally {
      clearTimeout(timer);
    }
  }
  throw new Error('Too many image redirects');
}

function readReplayGainValue(value) {
  if (!value) return null;
  if (typeof value.dB === 'number') return value.dB;
  if (typeof value === 'number') return value;
  const match = String(value).match(/-?\d+(?:\.\d+)?/);
  return match ? parseFloat(match[0]) : null;
}

function readReplayGainPeak(value) {
  if (!value) return null;
  if (typeof value.ratio === 'number') return value.ratio;
  if (typeof value === 'number') return value;
  const match = String(value).match(/\d+(?:\.\d+)?/);
  return match ? parseFloat(match[0]) : null;
}

function getReplayGainFields(metadata) {
  const common = metadata && metadata.common ? metadata.common : {};
  const format = metadata && metadata.format ? metadata.format : {};
  return {
    replayGainTrackDb: readReplayGainValue(common.replaygain_track_gain) ?? readReplayGainValue(format.trackGain),
    replayGainAlbumDb: readReplayGainValue(common.replaygain_album_gain) ?? readReplayGainValue(format.albumGain),
    replayGainTrackPeak: readReplayGainPeak(common.replaygain_track_peak),
    replayGainAlbumPeak: readReplayGainPeak(common.replaygain_album_peak),
  };
}

async function loadImageBufferFromSource(source) {
  if (!source || typeof source !== 'string') return null;
  if (/^https:\/\//i.test(source)) {
    try { return (await fetchAllowedImage(source, { 'User-Agent': APP_USER_AGENT, 'Accept': 'image/*,*/*;q=0.8' })).imageBuffer; }
    catch (e) { return null; }
  }
  if (source.startsWith('data:image/')) {
    if (source.length > Math.ceil(MAX_IMAGE_BYTES * 4 / 3) + 1024) return null;
    const dataMatch = source.match(/^data:image\/[a-z0-9.+-]+;base64,/i);
    if (!dataMatch) return null;
    const base64Data = source.slice(dataMatch[0].length);
    const imageBuffer = Buffer.from(base64Data, 'base64');
    return imageBuffer.length <= MAX_IMAGE_BYTES ? imageBuffer : null;
  }
  let imagePath = source;
  if (source.startsWith('file://')) {
    try { imagePath = fileURLToPath(source); }
    catch (e) { return null; }
  }
  if (!isExistingFileWithExt(imagePath, IMAGE_EXTENSIONS)) return null;
  let handle = null;
  try {
    handle = await fs.promises.open(imagePath, 'r');
    const stat = await handle.stat();
    if (!stat.isFile() || stat.size > MAX_IMAGE_BYTES) return null;
    const imageBuffer = Buffer.alloc(Math.min(MAX_IMAGE_BYTES + 1, stat.size + 1));
    let total = 0;
    while (total < imageBuffer.length) {
      const result = await handle.read(imageBuffer, total, imageBuffer.length - total, total);
      if (!result.bytesRead) break;
      total += result.bytesRead;
    }
    if (total !== stat.size) return null;
    return imageBuffer.subarray(0, total);
  } catch (e) {
    return null;
  } finally {
    if (handle) await handle.close().catch(() => { });
  }
}

async function fetchImageBuffer(url) {
  return fetchAllowedImage(url, { 'User-Agent': APP_USER_AGENT, 'Accept': 'image/*,*/*;q=0.8' });
}

async function fetchCoverImageWithFallback(sourceUrl) {
  const urls = [sourceUrl];
  if (/\/front-\d+$/i.test(sourceUrl)) {
    urls.push(sourceUrl.replace(/\/front-\d+$/i, '/front-500'));
    urls.push(sourceUrl.replace(/\/front-\d+$/i, '/front-250'));
    urls.push(sourceUrl.replace(/\/front-\d+$/i, '/front'));
  }
  let lastError = null;
  for (const url of [...new Set(urls)]) {
    try { return await fetchImageBuffer(url); }
    catch (e) { lastError = e; }
  }
  throw lastError || new Error('cover unavailable');
}

async function fetchCachedCoverImage(sourceUrl) {
  const key = String(sourceUrl || '').trim();
  if (!key) throw new Error('cover URL missing');
  if (!metadataCoverCache.has(key)) {
    metadataCoverCache.set(key, fetchCoverImageWithFallback(key).catch(err => {
      metadataCoverCache.delete(key);
      throw err;
    }));
    if (metadataCoverCache.size > MAX_IMAGE_CACHE_ENTRIES) metadataCoverCache.delete(metadataCoverCache.keys().next().value);
  }
  return metadataCoverCache.get(key);
}

async function writeFolderJpgForTrack(filePath, imageSourceOrBuffer) {
  filePath = normalizePathInput(filePath);
  if (!isExistingFileWithExt(filePath, AUDIO_EXTENSIONS)) return false;
  const imageBuffer = Buffer.isBuffer(imageSourceOrBuffer) ? imageSourceOrBuffer : await loadImageBufferFromSource(imageSourceOrBuffer);
  if (!imageBuffer || !imageBuffer.length) return false;
  const folderJpgPath = path.join(path.dirname(filePath), 'folder.jpg');
  const tmpPath = path.join(path.dirname(filePath), `.folder.jpg.${process.pid}.${Date.now()}.${crypto.randomBytes(6).toString('hex')}.tmp`);
  try {
    await fs.promises.writeFile(tmpPath, imageBuffer);
    await fs.promises.rename(tmpPath, folderJpgPath);
  } catch (e) {
    try { await fs.promises.unlink(tmpPath); } catch (_) { }
    throw e;
  }
  return true;
}

const AUDIO_EXTENSIONS = ['.mp3', '.wav', '.flac', '.m4a'];
const IMAGE_EXTENSIONS = ['.jpg', '.jpeg', '.png', '.bmp', '.webp', '.tiff', '.tif', '.gif', '.avif'];

registerIpcHandler('load-library', () => {
  return readAppDataFile(LIBRARY_FILE, [], 'library.json', (value) => {
    if (!Array.isArray(value)) throw new Error('expected an array');
    validateBackupLibrary(value);
  });
});

registerIpcHandler('save-library', async (event, musicFiles) => {
  if (backupRestoreInProgress || !Array.isArray(musicFiles)) return false;
  try { await queueJsonWrite(LIBRARY_FILE, musicFiles); return true; }
  catch (e) { console.error('Failed to save library:', e); return false; }
});

registerIpcHandler('load-liked-songs', () => {
  if (!fs.existsSync(LIKED_SONGS_FILE)) return null;
  return readAppDataFile(LIKED_SONGS_FILE, [], 'liked-songs.json', (value) => {
    if (!Array.isArray(value) || value.length > MAX_LIBRARY_TRACKS || value.some((item) => typeof item !== 'string')) throw new Error('expected an array of file paths');
  });
});

registerIpcHandler('save-liked-songs', async (event, likedSongs) => {
  if (backupRestoreInProgress || !Array.isArray(likedSongs) || likedSongs.some(item => typeof item !== 'string')) return false;
  try { await queueJsonWrite(LIKED_SONGS_FILE, likedSongs); return true; }
  catch (e) { console.error('Failed to save liked songs:', e); return false; }
});

registerIpcHandler('export-backup', async (event, extras) => {
  const stamp = new Date().toISOString().slice(0, 10);
  const { canceled, filePath } = await dialog.showSaveDialog(mainWindow, {
    filters: [{ name: `${APP_NAME} Backup`, extensions: ['json'] }],
    defaultPath: `${APP_ID}_backup_${stamp}.json`,
  });
  if (canceled || !filePath) return { ok: false, canceled: true };
  try {
    await waitForPendingDataWrites();
    const storedSettings = readJsonFileStrict(SETTINGS_FILE, {});
    if (!isPlainObject(storedSettings)) throw new Error('Could not export backup: settings.json must contain an object');
    const data = {
      library: readJsonFileStrict(LIBRARY_FILE, []),
      playlists: readJsonFileStrict(PLAYLISTS_FILE, []),
      mappings: readJsonFileStrict(MAPPINGS_FILE, {}),
      settings: sanitizeSettingsForBackup(appSettings),
      likedSongs: readJsonFileStrict(LIKED_SONGS_FILE, extras && Array.isArray(extras.likedSongs) ? extras.likedSongs : []),
      exportedFrom: APP_NAME,
    };
    const payload = {
      app: APP_NAME,
      schemaVersion: 1,
      exportedAt: new Date().toISOString(),
      data,
    };
    validateBackupData(payload);
    const text = JSON.stringify(payload, null, 2);
    if (Buffer.byteLength(text, 'utf8') > MAX_BACKUP_BYTES) throw new Error('Backup exceeds the 64 MB export limit');
    await fs.promises.writeFile(filePath, text, { encoding: 'utf8', mode: 0o600 });
    return { ok: true, filePath, summary: summarizeBackupData(data) };
  } catch (e) {
    return { ok: false, error: e.message || String(e) };
  }
});

registerIpcHandler('import-backup', async () => {
  const { canceled, filePaths } = await dialog.showOpenDialog(mainWindow, {
    properties: ['openFile'],
    filters: [{ name: `${APP_NAME} Backup`, extensions: ['json'] }],
  });
  if (canceled || !filePaths || !filePaths[0]) return { ok: false, canceled: true };
  let handle = null;
  try {
    handle = await fs.promises.open(filePaths[0], 'r');
    const stat = await handle.stat();
    if (!stat.isFile() || stat.size > MAX_BACKUP_BYTES) throw new Error('Backup file is too large');
    const text = await handle.readFile({ encoding: 'utf8' });
    if (Buffer.byteLength(text, 'utf8') > MAX_BACKUP_BYTES) throw new Error('Backup file is too large');
    const data = validateBackupData(JSON.parse(text));
    const token = crypto.randomBytes(24).toString('hex');
    pendingBackupImports.clear();
    pendingBackupImports.set(token, { data, createdAt: Date.now() });
    setTimeout(() => pendingBackupImports.delete(token), BACKUP_TOKEN_TTL_MS).unref();
    return { ok: true, token, filePath: filePaths[0], summary: summarizeBackupData(data) };
  } catch (e) {
    return { ok: false, error: e.message || String(e) };
  } finally {
    if (handle) await handle.close().catch(() => { });
  }
});

registerIpcHandler('restore-backup', async (event, token) => {
  token = String(token || '');
  const pending = pendingBackupImports.get(token);
  if (!pending || Date.now() - pending.createdAt > BACKUP_TOKEN_TTL_MS) return { ok: false, error: 'Backup preview expired. Select the backup again.' };
  if (reservedDownloadRequestIds.size || activeYtdlpDownloads.size) return { ok: false, error: 'Wait for active downloads to finish before restoring a backup.' };
  pendingBackupImports.delete(token);
  if (backupRestoreInProgress) return { ok: false, error: 'Another backup restore is already running.' };
  backupRestoreInProgress = true;
  try {
    const data = pending.data;
    const restoredSettings = { minimizeToTray: false, useNativeTitleBar: false, ytdlCookiesMode: 'none', ytdlCookiesBrowser: 'firefox', ytdlCookiesFile: '', ...data.settings };
    for (const key of SENSITIVE_SETTING_KEYS) {
      if (appSettings[key]) restoredSettings[key] = appSettings[key];
    }
    const restoredLikedSongs = Array.isArray(data.likedSongs) ? data.likedSongs : readJsonFile(LIKED_SONGS_FILE, []);
    await waitForPendingDataWrites();
    await replaceJsonFilesTransaction([
      { filePath: LIBRARY_FILE, data: data.library },
      { filePath: PLAYLISTS_FILE, data: data.playlists },
      { filePath: MAPPINGS_FILE, data: data.mappings },
      { filePath: SETTINGS_FILE, data: serializeSettingsForDisk(restoredSettings) },
      { filePath: LIKED_SONGS_FILE, data: restoredLikedSongs },
    ]);
    appSettings = restoredSettings;
    const warnings = await reconcileRestoredRuntime(restoredSettings);
    return { ok: true, summary: summarizeBackupData(data), likedSongs: restoredLikedSongs, warnings };
  } catch (e) {
    return { ok: false, error: e.message || String(e) };
  } finally {
    backupRestoreInProgress = false;
  }
});

registerIpcHandler('restore-app-state', async (event, snapshot) => {
  if (reservedDownloadRequestIds.size || activeYtdlpDownloads.size) return { ok: false, error: 'Wait for active downloads to finish before undoing a backup restore.' };
  if (backupRestoreInProgress) return { ok: false, error: 'Another backup restore is already running.' };
  backupRestoreInProgress = true;
  try {
    const data = validateAppStateSnapshot(snapshot);
    const restoredSettings = { minimizeToTray: false, useNativeTitleBar: false, ytdlCookiesMode: 'none', ytdlCookiesBrowser: 'firefox', ytdlCookiesFile: '', ...data.settings };
    await waitForPendingDataWrites();
    await replaceJsonFilesTransaction([
      { filePath: LIBRARY_FILE, data: data.library },
      { filePath: PLAYLISTS_FILE, data: data.playlists },
      { filePath: MAPPINGS_FILE, data: data.mappings },
      { filePath: SETTINGS_FILE, data: serializeSettingsForDisk(restoredSettings) },
      { filePath: LIKED_SONGS_FILE, data: data.likedSongs },
    ]);
    appSettings = restoredSettings;
    return { ok: true, warnings: await reconcileRestoredRuntime(restoredSettings) };
  } catch (e) {
    return { ok: false, error: e.message || String(e) };
  } finally {
    backupRestoreInProgress = false;
  }
});

registerIpcHandler('check-library-files', async (event, musicFiles) => {
  if (!Array.isArray(musicFiles)) return { ok: false, missing: [] };
  const missing = [];
  for (let i = 0; i < musicFiles.length; i++) {
    const file = musicFiles[i];
    const filePath = normalizePathInput(file && typeof file.filePath === 'string' ? file.filePath : '');
    if (!path.isAbsolute(filePath) || !AUDIO_EXTENSIONS.includes(path.extname(filePath).toLowerCase())) continue;
    try {
      const stat = await fs.promises.stat(filePath);
      if (!stat.isFile()) missing.push(filePath);
    } catch (e) {
      missing.push(filePath);
    }
    if (i % 100 === 0) await new Promise((resolve) => setImmediate(resolve));
  }
  return { ok: true, missing };
});

// Back-fill year/genre for existing library files that are missing those fields
registerIpcHandler('backfill-metadata', async (event, musicFiles) => {
  if (!Array.isArray(musicFiles)) return { ok: false, updates: [] };
  const updates = [];
  const metadataFields = ['year', 'genre', 'discNo', 'discTotal', 'trackTotal', 'replayGainTrackDb', 'replayGainAlbumDb', 'replayGainTrackPeak', 'replayGainAlbumPeak'];
  for (const f of musicFiles) {
    if (!f || typeof f !== 'object') continue;
    const filePath = normalizePathInput(f.filePath);
    if (!filePath || !path.isAbsolute(filePath)) continue;
    if (!isExistingFileWithExt(filePath, AUDIO_EXTENSIONS)) continue;
    const patch = { filePath };
    if (metadataFields.some((field) => f[field] === null || f[field] === undefined)) {
      try {
        const metadata = await mm.parseFile(filePath, { duration: false });
        const rg = getReplayGainFields(metadata);
        const values = {
          year: metadata.common.year || null,
          genre: metadata.common.genre ? metadata.common.genre[0] : null,
          discNo: metadata.common.disk && metadata.common.disk.no ? metadata.common.disk.no : 0,
          discTotal: metadata.common.disk && metadata.common.disk.of ? metadata.common.disk.of : 0,
          trackTotal: metadata.common.track && metadata.common.track.of ? metadata.common.track.of : 0,
          replayGainTrackDb: rg.replayGainTrackDb,
          replayGainAlbumDb: rg.replayGainAlbumDb,
          replayGainTrackPeak: rg.replayGainTrackPeak,
          replayGainAlbumPeak: rg.replayGainAlbumPeak,
        };
        for (const field of metadataFields) {
          if (f[field] === null || f[field] === undefined) patch[field] = values[field];
        }
      } catch (e) { }
    }
    if (Object.keys(patch).length > 1) updates.push(patch);
  }
  return { ok: true, updates };
});

registerIpcHandler('load-playlists', () => {
  return readAppDataFile(PLAYLISTS_FILE, [], 'playlists.json', (value) => {
    if (!Array.isArray(value)) throw new Error('expected an array');
    validateBackupPlaylists(value);
  });
});

registerIpcHandler('save-playlists', async (event, playlists) => {
  if (backupRestoreInProgress || !Array.isArray(playlists)) return false;
  try { await queueJsonWrite(PLAYLISTS_FILE, playlists); return true; }
  catch (e) { console.error('Failed to save playlists:', e); return false; }
});

registerIpcHandler('load-mappings', () => {
  return readAppDataFile(MAPPINGS_FILE, {}, 'mappings.json', (value) => {
    if (!isPlainObject(value)) throw new Error('expected an object');
    validateBackupMappings(value);
  });
});

registerIpcHandler('save-mappings', async (event, mappings) => {
  if (backupRestoreInProgress || !mappings || typeof mappings !== 'object' || Array.isArray(mappings)) return false;
  try { await queueJsonWrite(MAPPINGS_FILE, mappings); return true; }
  catch (e) { console.error('Failed to save mappings:', e); return false; }
});

registerIpcHandler('load-settings', () => {
  loadSettingsFromDisk();
  if (settingsLoadError) throw settingsLoadError;
  if (appSettings && appSettings.discordRpc) {
    discordConnect();
  }
  return appSettings;
});

registerIpcHandler('save-settings', async (event, settings) => {
  if (backupRestoreInProgress || !settings || typeof settings !== 'object' || Array.isArray(settings)) return false;
  try {
    const wasDiscord = appSettings.discordRpc;
    await queueJsonWrite(SETTINGS_FILE, serializeSettingsForDisk(settings));
    appSettings = { ...settings };
    // Handle Discord toggle
    if (settings.discordRpc && !wasDiscord) discordConnect();
    else if (!settings.discordRpc && wasDiscord) { discordClear(); if (discordClient) { try { discordClient.destroy(); } catch (e) { } discordClient = null; discordEnabled = false; } }
    return true;
  }
  catch (e) { console.error('Failed to save settings:', e); return false; }
});

registerIpcHandler('safe-storage-status', () => {
  return {
    encryptionAvailable: isSecureStorageAvailable(),
    backend: typeof safeStorage.getSelectedStorageBackend === 'function' ? safeStorage.getSelectedStorageBackend() : '',
  };
});

registerIpcHandler('clear-sensitive-setting', async (event, key) => {
  if (backupRestoreInProgress) return false;
  key = String(key || '');
  if (!SENSITIVE_SETTING_KEYS.includes(key)) return false;
  delete preservedEncryptedSettings[key];
  undecryptableSettingKeys.delete(key);
  appSettings[key] = '';
  try { await queueJsonWrite(SETTINGS_FILE, serializeSettingsForDisk(appSettings)); return true; }
  catch (e) { console.error('Failed to clear sensitive setting:', key, e); return false; }
});

// Discord RPC IPC handlers
registerIpcHandler('discord-update', async (event, title, artist, album, startTime) => {
  await discordSetActivity(title, artist, album, startTime);
  return true;
});
registerIpcHandler('discord-clear', async () => {
  await discordClear();
  return true;
});
registerIpcHandler('discord-status', () => { return { enabled: discordEnabled, error: discordLastError }; });

registerIpcHandler('get-metadata', async (event, filePath) => {
  filePath = normalizePathInput(filePath);
  if (!isExistingFileWithExt(filePath, AUDIO_EXTENSIONS)) return null;
  try {
    const metadata = await mm.parseFile(filePath);
    const rg = getReplayGainFields(metadata);
    return {
      year: metadata.common.year || null,
      codec: metadata.format.codec || null,
      bitrate: metadata.format.bitrate || null,
      sampleRate: metadata.format.sampleRate || null,
      genre: metadata.common.genre ? metadata.common.genre.join(', ') : null,
      albumartist: metadata.common.albumartist || null,
      discNo: metadata.common.disk && metadata.common.disk.no ? metadata.common.disk.no : 0,
      discTotal: metadata.common.disk && metadata.common.disk.of ? metadata.common.disk.of : 0,
      trackNo: metadata.common.track && metadata.common.track.no ? metadata.common.track.no : 0,
      trackTotal: metadata.common.track && metadata.common.track.of ? metadata.common.track.of : 0,
      replayGainTrackDb: rg.replayGainTrackDb,
      replayGainAlbumDb: rg.replayGainAlbumDb,
      replayGainTrackPeak: rg.replayGainTrackPeak,
      replayGainAlbumPeak: rg.replayGainAlbumPeak
    };
  } catch (e) {
    return null;
  }
});

function setFlacTag(flac, name, value) {
  if (value === null || value === undefined || value === '') return;
  const upper = name.toUpperCase();
  flac.tags = flac.tags.filter(item => item.split('=')[0].toUpperCase() !== upper);
  flac.tags.push(`${upper}=${String(value)}`);
}

function buildVorbisComment(vendorString, comments) {
  const vendor = Buffer.from(vendorString || APP_ID, 'utf8');
  const vendorLen = Buffer.alloc(4);
  vendorLen.writeUInt32LE(vendor.length, 0);
  const count = Buffer.alloc(4);
  count.writeUInt32LE(comments.length, 0);
  const parts = [vendorLen, vendor, count];
  comments.forEach(comment => {
    const body = Buffer.from(comment, 'utf8');
    const len = Buffer.alloc(4);
    len.writeUInt32LE(body.length, 0);
    parts.push(len, body);
  });
  return Buffer.concat(parts);
}

function parseVorbisComment(block) {
  let offset = 0;
  if (!block || block.length < 8) return { vendor: APP_ID, tags: [] };
  const vendorLen = block.readUInt32LE(offset); offset += 4;
  const vendor = block.slice(offset, offset + vendorLen).toString('utf8'); offset += vendorLen;
  if (offset + 4 > block.length) return { vendor, tags: [] };
  const count = block.readUInt32LE(offset); offset += 4;
  const tags = [];
  for (let i = 0; i < count && offset + 4 <= block.length; i++) {
    const len = block.readUInt32LE(offset); offset += 4;
    if (offset + len > block.length) break;
    tags.push(block.slice(offset, offset + len).toString('utf8'));
    offset += len;
  }
  return { vendor, tags };
}

function buildFlacPictureBlock(image) {
  const mime = Buffer.from((image.mime || 'image/jpeg').split(';')[0], 'ascii');
  const description = Buffer.alloc(0);
  const data = image.imageBuffer;
  const pictureType = Buffer.alloc(4);
  const mimeLength = Buffer.alloc(4);
  const descriptionLength = Buffer.alloc(4);
  const width = Buffer.alloc(4);
  const height = Buffer.alloc(4);
  const depth = Buffer.alloc(4);
  const colors = Buffer.alloc(4);
  const pictureLength = Buffer.alloc(4);
  pictureType.writeUInt32BE(3, 0);
  mimeLength.writeUInt32BE(mime.length, 0);
  descriptionLength.writeUInt32BE(description.length, 0);
  width.writeUInt32BE(0, 0);
  height.writeUInt32BE(0, 0);
  depth.writeUInt32BE(0, 0);
  colors.writeUInt32BE(0, 0);
  pictureLength.writeUInt32BE(data.length, 0);
  return Buffer.concat([pictureType, mimeLength, mime, descriptionLength, description, width, height, depth, colors, pictureLength, data]);
}

function buildFlacMetadataBlock(type, data, isLast) {
  if (data.length > 0xffffff) throw new Error('FLAC metadata block is too large');
  const header = Buffer.alloc(4);
  header[0] = (isLast ? 0x80 : 0) | (type & 0x7f);
  header.writeUIntBE(data.length, 1, 3);
  return Buffer.concat([header, data]);
}

async function updateFlacMetadata(filePath, tags) {
  const originalStat = await fs.promises.stat(filePath);
  if (!originalStat.isFile() || originalStat.size > MAX_METADATA_EDIT_BYTES) throw new Error('FLAC file exceeds the 512 MB metadata editing limit');
  const input = await fs.promises.readFile(filePath);
  const markerOffset = input.indexOf(Buffer.from('fLaC'));
  if (markerOffset < 0) throw new Error('FLAC marker not found');
  const prefix = input.slice(0, markerOffset);
  let offset = markerOffset + 4;
  const blocks = [];
  while (offset + 4 <= input.length) {
    const first = input[offset];
    const isLast = !!(first & 0x80);
    const type = first & 0x7f;
    const length = input.readUIntBE(offset + 1, 3);
    offset += 4;
    if (offset + length > input.length) throw new Error('Invalid FLAC metadata length');
    blocks.push({ type, data: input.slice(offset, offset + length) });
    offset += length;
    if (isLast) break;
  }
  if (!blocks.length || blocks[0].type !== 0) throw new Error('Invalid FLAC streaminfo block');
  const audioFrames = input.slice(offset);
  let vorbisIndex = blocks.findIndex(block => block.type === 4);
  let parsed = vorbisIndex >= 0 ? parseVorbisComment(blocks[vorbisIndex].data) : { vendor: APP_ID, tags: [] };
  const flac = { tags: parsed.tags };
  if (tags.title) setFlacTag(flac, 'TITLE', tags.title);
  if (tags.artist) setFlacTag(flac, 'ARTIST', tags.artist);
  if (tags.album) setFlacTag(flac, 'ALBUM', tags.album);
  if (tags.performerInfo) setFlacTag(flac, 'ALBUMARTIST', tags.performerInfo);
  if (tags.year) setFlacTag(flac, 'DATE', tags.year);
  if (tags.genre) setFlacTag(flac, 'GENRE', tags.genre);
  if (tags.trackNumber) setFlacTag(flac, 'TRACKNUMBER', tags.trackNumber);
  if (tags.trackTotal) setFlacTag(flac, 'TOTALTRACKS', tags.trackTotal);
  if (tags.discNumber) setFlacTag(flac, 'DISCNUMBER', tags.discNumber);
  if (tags.discTotal) setFlacTag(flac, 'TOTALDISCS', tags.discTotal);
  if (tags.partOfSet) {
    setFlacTag(flac, 'DISCNUMBER', tags.partOfSet);
    const parts = String(tags.partOfSet).split('/');
    if (parts[1]) setFlacTag(flac, 'TOTALDISCS', parts[1]);
  }
  const vorbisBlock = { type: 4, data: buildVorbisComment(parsed.vendor, flac.tags) };
  if (vorbisIndex >= 0) blocks[vorbisIndex] = vorbisBlock;
  else blocks.splice(1, 0, vorbisBlock);
  if (tags.image && tags.image.imageBuffer) {
    for (let i = blocks.length - 1; i >= 0; i--) {
      if (blocks[i].type === 6) blocks.splice(i, 1);
    }
    blocks.push({ type: 6, data: buildFlacPictureBlock(tags.image) });
  }
  const metadata = blocks.map((block, index) => buildFlacMetadataBlock(block.type, block.data, index === blocks.length - 1));
  const outputSize = prefix.length + 4 + metadata.reduce((total, block) => total + block.length, 0) + audioFrames.length;
  if (outputSize > MAX_METADATA_EDIT_BYTES) throw new Error('Edited FLAC would exceed the 512 MB metadata editing limit');
  const output = Buffer.concat([prefix, Buffer.from('fLaC'), ...metadata, audioFrames]);
  // Write to a temp file then rename so a crash mid-write can't corrupt the original audio
  const tmpPath = path.join(path.dirname(filePath), `.${path.basename(filePath)}.${process.pid}.${Date.now()}.${crypto.randomBytes(6).toString('hex')}.tmp`);
  try {
    await fs.promises.writeFile(tmpPath, output);
    await preserveReplacementMode(tmpPath, originalStat);
    await fs.promises.rename(tmpPath, filePath);
  } catch (e) {
    try { await fs.promises.unlink(tmpPath); } catch (_) { }
    throw e;
  }
  return true;
}

async function preserveReplacementMode(tempPath, originalStat) {
  try { await fs.promises.chmod(tempPath, originalStat.mode); }
  catch (e) { console.warn('Could not preserve audio file mode:', e && e.message ? e.message : e); }
}

async function updateMp3Metadata(filePath, tags) {
  const tmpPath = path.join(path.dirname(filePath), `.${path.basename(filePath)}.${process.pid}.${Date.now()}.${crypto.randomBytes(6).toString('hex')}.tmp.mp3`);
  try {
    const originalStat = await fs.promises.stat(filePath);
    if (!originalStat.isFile() || originalStat.size > MAX_METADATA_EDIT_BYTES) throw new Error('MP3 file exceeds the 512 MB metadata editing limit');
    await fs.promises.copyFile(filePath, tmpPath, fs.constants.COPYFILE_EXCL);
    const result = NodeID3.update(tags, tmpPath);
    if (result !== true) throw (result instanceof Error ? result : new Error('MP3 metadata writer returned an invalid result'));
    const updatedStat = await fs.promises.stat(tmpPath);
    if (!updatedStat.isFile() || updatedStat.size > MAX_METADATA_EDIT_BYTES) throw new Error('Edited MP3 would exceed the 512 MB metadata editing limit');
    await preserveReplacementMode(tmpPath, originalStat);
    await fs.promises.rename(tmpPath, filePath);
  } catch (e) {
    try { await fs.promises.unlink(tmpPath); } catch (_) { }
    throw e;
  }
  return true;
}

const metadataWriteQueues = new Map();

function queueMetadataWrite(filePath, task) {
  const previous = metadataWriteQueues.get(filePath) || Promise.resolve();
  const next = previous.catch(() => { }).then(task);
  metadataWriteQueues.set(filePath, next);
  const cleanup = () => { if (metadataWriteQueues.get(filePath) === next) metadataWriteQueues.delete(filePath); };
  next.then(cleanup, cleanup);
  return next;
}

function parseMetadataNumberPair(value) {
  const parts = String(value || '').split('/');
  return {
    no: parseInt(parts[0] || '0', 10) || 0,
    total: parseInt(parts[1] || '0', 10) || 0,
  };
}

async function mergeCompositeMetadataNumbers(filePath, tags) {
  const next = { ...tags };
  const trackTouched = Object.prototype.hasOwnProperty.call(next, 'trackNumber') || Object.prototype.hasOwnProperty.call(next, 'trackTotal');
  const discTouched = Object.prototype.hasOwnProperty.call(next, 'discNumber') || Object.prototype.hasOwnProperty.call(next, 'discTotal') || Object.prototype.hasOwnProperty.call(next, 'partOfSet');
  if (!trackTouched && !discTouched) return next;
  const metadata = await mm.parseFile(filePath, { duration: false, skipCovers: true });
  if (trackTouched) {
    const incoming = parseMetadataNumberPair(next.trackNumber);
    const currentNo = metadata.common.track && metadata.common.track.no ? metadata.common.track.no : 0;
    const currentTotal = metadata.common.track && metadata.common.track.of ? metadata.common.track.of : 0;
    const finalNo = incoming.no || currentNo;
    const finalTotal = parseInt(next.trackTotal || '0', 10) || incoming.total || currentTotal;
    if (finalNo) next.trackNumber = finalTotal ? `${finalNo}/${finalTotal}` : String(finalNo);
    if (finalTotal) next.trackTotal = String(finalTotal);
  }
  if (discTouched) {
    const incoming = parseMetadataNumberPair(next.partOfSet || next.discNumber);
    const currentNo = metadata.common.disk && metadata.common.disk.no ? metadata.common.disk.no : 0;
    const currentTotal = metadata.common.disk && metadata.common.disk.of ? metadata.common.disk.of : 0;
    const finalNo = incoming.no || currentNo;
    const finalTotal = parseInt(next.discTotal || '0', 10) || incoming.total || currentTotal;
    if (finalNo) next.discNumber = String(finalNo);
    if (finalTotal) next.discTotal = String(finalTotal);
    if (finalNo || finalTotal) next.partOfSet = finalNo ? `${finalNo}${finalTotal ? `/${finalTotal}` : ''}` : `0/${finalTotal}`;
  }
  return next;
}

registerIpcHandler('save-metadata', async (event, filePaths, tags, saveFolderJpg) => {
  try {
    if (!Array.isArray(filePaths) || filePaths.length === 0 || !tags || typeof tags !== 'object') return { ok: false, error: 'Invalid metadata save request' };
    let success = true;
    const normalizedFilePaths = filePaths.map(normalizePathInput);
    const editablePaths = normalizedFilePaths.filter(fp => isExistingFileWithExt(fp, ['.mp3', '.flac']));
    if (editablePaths.length !== filePaths.length) return { ok: false, error: 'Only existing MP3 and FLAC files can be edited' };
    for (const fp of editablePaths) {
      const fileStat = await fs.promises.lstat(fp);
      if (fileStat.isSymbolicLink()) return { ok: false, error: 'Metadata editing does not support symbolic links' };
      if (!fileStat.isFile()) return { ok: false, error: 'Metadata target must be a regular file' };
      if (fileStat.nlink > 1) return { ok: false, error: 'Metadata editing does not support files with multiple hard links' };
    }

    // Helper: get MIME type from file extension
    function getMimeFromExt(filePath) {
      const ext = path.extname(filePath).toLowerCase();
      const mimeMap = { '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.png': 'image/png',
        '.bmp': 'image/bmp', '.webp': 'image/webp', '.gif': 'image/gif',
        '.tiff': 'image/tiff', '.tif': 'image/tiff', '.avif': 'image/avif' };
      return mimeMap[ext] || 'image/jpeg';
    }
    let folderImageBuffer = null;

    // Normalize image: if it's a remote cover URL, download it into buffer form.
    if (tags.image && /^https:\/\//i.test(tags.image)) {
      try {
        const cover = await fetchCachedCoverImage(tags.image);
        folderImageBuffer = cover.imageBuffer;
        tags.image = {
          mime: cover.contentType.split(';')[0],
          type: { id: 3, name: 'front cover' },
          description: '',
          imageBuffer: cover.imageBuffer,
        };
      } catch (coverErr) {
        return { ok: false, error: `Cover download failed: ${coverErr.message || coverErr}` };
      }
    } else if (tags.image) {
      const imageSource = tags.image;
      const imageBuffer = await loadImageBufferFromSource(imageSource);
      if (!imageBuffer) return { ok: false, error: 'Selected cover image is unavailable or larger than 12 MB' };
      const mimeMatch = imageSource.match(/^data:(image\/[a-z0-9.+-]+);base64,/i);
      const mimeType = mimeMatch ? mimeMatch[1].toLowerCase() : getMimeFromExt(normalizePathInput(imageSource));
      folderImageBuffer = imageBuffer;
      tags.image = {
        mime: mimeType,
        type: { id: 3, name: 'front cover' },
        description: '',
        imageBuffer: imageBuffer
      };
    }

    for (let fp of editablePaths) {
      try {
        await queueMetadataWrite(fp, async () => {
          const ext = path.extname(fp).toLowerCase();
          const writerTags = await mergeCompositeMetadataNumbers(fp, tags);
          if (ext === '.mp3') await updateMp3Metadata(fp, writerTags);
          else if (ext === '.flac' && !(await updateFlacMetadata(fp, writerTags))) success = false;
        });
      } catch (e) {
        console.error(`Failed to save metadata for ${fp}:`, e);
        return { ok: false, error: `${path.basename(fp)}: ${e.message || e}` };
      }
    }
    if (!success) return { ok: false, error: 'Metadata writer returned false' };
    const warnings = [];
    if (saveFolderJpg && folderImageBuffer) {
      const writtenDirs = new Set();
      for (const fp of editablePaths) {
        const dir = path.dirname(fp);
        if (writtenDirs.has(dir)) continue;
        writtenDirs.add(dir);
        try { await writeFolderJpgForTrack(fp, folderImageBuffer); }
        catch (e) { warnings.push(`Could not write ${path.join(dir, 'folder.jpg')}: ${e.message || e}`); }
      }
    }
    return warnings.length ? { ok: true, warnings } : true;
  } catch (e) {
    console.error(e);
    return { ok: false, error: e.message || String(e) };
  }
});

registerIpcHandler('save-folder-covers', async (event, musicFiles) => {
  if (!Array.isArray(musicFiles)) return { ok: false, saved: 0, failed: 0 };
  const byDir = new Map();
  for (const file of musicFiles) {
    const filePath = normalizePathInput(file && file.filePath);
    if (!file || !filePath || !file.picture || !isExistingFileWithExt(filePath, AUDIO_EXTENSIONS)) continue;
    const dir = path.dirname(filePath);
    if (!byDir.has(dir)) byDir.set(dir, { ...file, filePath });
  }
  let saved = 0;
  let failed = 0;
  const failures = [];
  for (const file of byDir.values()) {
    try {
      if (await writeFolderJpgForTrack(file.filePath, file.picture)) saved++;
      else {
        failed++;
        failures.push({ folder: path.dirname(file.filePath), filePath: file.filePath, reason: 'cover source unavailable' });
      }
    } catch (e) {
      failed++;
      failures.push({ folder: path.dirname(file.filePath), filePath: file.filePath, reason: e.message || String(e) });
      console.error('Failed to save folder cover:', file.filePath, e);
    }
  }
  return { ok: true, saved, failed, failures };
});

registerIpcHandler('search-musicbrainz', async (event, query) => {
  try {
    const url = `https://musicbrainz.org/ws/2/release/?query=${encodeURIComponent(query)}&fmt=json`;
    const res = await fetch(url, { headers: { 'User-Agent': `${APP_USER_AGENT} ( zafer@example.com )` } });
    const data = await res.json();
    return data.releases || [];
  } catch (e) { return []; }
});

registerIpcHandler('get-musicbrainz-release', async (event, releaseId) => {
  try {
    const res = await fetch(`https://musicbrainz.org/ws/2/release/${releaseId}?inc=recordings+artists&fmt=json`, { headers: { 'User-Agent': `${APP_USER_AGENT} ( zafer@example.com )` } });
    return await res.json();
  } catch (e) { return null; }
});

function safeYear(value) {
  const match = String(value || '').match(/\d{4}/);
  return match ? match[0] : '';
}

function normalizeMetadataOptions(options) {
  if (options && typeof options === 'object') return options;
  return { discogsToken: String(options || '') };
}

function normalizeSourceResult(source, id, title, artist, year, extra = {}) {
  return { source, id: String(id || ''), title: title || 'Unknown Album', artist: artist || 'Unknown Artist', date: year || '', thumb: extra.thumb || '', label: extra.label || '' };
}

function toArtistCredit(name) {
  return [{ name: name || 'Unknown Artist' }];
}

function joinSourceNames(items) {
  return Array.isArray(items) ? items.map(item => item && (item.name || item.artist || '')).filter(Boolean).join(', ') : '';
}

async function getSpotifyAccessToken(clientId, clientSecret) {
  clientId = String(clientId || '').trim();
  clientSecret = String(clientSecret || '').trim();
  if (!clientId || !clientSecret) return '';
  const cacheKey = crypto.createHash('sha1').update(clientId + ':' + clientSecret).digest('hex');
  if (spotifyTokenCache.token && spotifyTokenCache.key === cacheKey && Date.now() < spotifyTokenCache.expiresAt - 60000) return spotifyTokenCache.token;
  const res = await fetch('https://accounts.spotify.com/api/token', {
    method: 'POST',
    headers: {
      'Authorization': 'Basic ' + Buffer.from(clientId + ':' + clientSecret).toString('base64'),
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: 'grant_type=client_credentials',
  });
  if (!res.ok) throw new Error(`Spotify auth HTTP ${res.status}`);
  const data = await res.json();
  spotifyTokenCache = { token: data.access_token || '', expiresAt: Date.now() + ((data.expires_in || 3600) * 1000), key: cacheKey };
  return spotifyTokenCache.token;
}

function spotifyArtistNames(items) {
  return Array.isArray(items) ? items.map(a => a && a.name).filter(Boolean).join(', ') : '';
}

function spotifyImage(images, preferredIndex = 1) {
  if (!Array.isArray(images) || !images.length) return '';
  return (images[preferredIndex] || images[0]).url || '';
}

async function fetchSpotifyJson(url, token) {
  const parsed = new URL(String(url || ''));
  if (parsed.protocol !== 'https:' || parsed.hostname !== 'api.spotify.com' || !parsed.pathname.startsWith('/v1/')) throw new Error('Invalid Spotify API URL');
  const res = await fetch(parsed.href, { headers: { 'Authorization': 'Bearer ' + token, 'User-Agent': APP_USER_AGENT } });
  if (!res.ok) throw new Error(`Spotify HTTP ${res.status}`);
  return await res.json();
}

function normalizeMetadataRelease(source, data) {
  if (!data) return null;
  if (source === 'musicbrainz') return { ...data, source: 'MusicBrainz' };
  if (source === 'itunes') {
    const album = data.album || {};
    const songs = data.songs || [];
    return {
      source: 'iTunes',
      id: `itunes:${album.collectionId || ''}`,
      title: album.collectionName || '',
      date: safeYear(album.releaseDate),
      genres: album.primaryGenreName ? [{ name: album.primaryGenreName }] : [],
      'artist-credit': toArtistCredit(album.artistName),
      coverUrl: album.artworkUrl100 ? album.artworkUrl100.replace(/100x100bb\.jpg$/i, '600x600bb.jpg') : '',
      media: [{ position: 1, tracks: songs.map((song, index) => ({ title: song.trackName || '', artist: song.artistName || album.artistName || '', position: song.trackNumber || (index + 1), length: song.trackTimeMillis || 0 })) }]
    };
  }
  if (source === 'deezer') {
    return {
      source: 'Deezer',
      id: `deezer:${data.id || ''}`,
      title: data.title || '',
      date: safeYear(data.release_date),
      genres: data.genres && data.genres.data && data.genres.data[0] ? [{ name: data.genres.data[0].name }] : [],
      'artist-credit': toArtistCredit(data.artist && data.artist.name),
      coverUrl: data.cover_xl || data.cover_big || data.cover_medium || '',
      media: [{ position: 1, tracks: data.tracks && data.tracks.data ? data.tracks.data.map((song, index) => ({ title: song.title || '', artist: song.artist && song.artist.name || data.artist && data.artist.name || '', position: song.track_position || (index + 1), length: song.duration ? song.duration * 1000 : 0 })) : [] }]
    };
  }
  if (source === 'discogs') {
    const titleParts = String(data.title || '').split(' - ');
    const artist = data.artists_sort || (data.artists && data.artists.map(a => a.name).join(', ')) || titleParts[0] || '';
    const albumTitle = titleParts.length > 1 ? titleParts.slice(1).join(' - ') : (data.title || '');
    return {
      source: 'Discogs',
      id: `discogs:${data.id || ''}`,
      title: albumTitle,
      date: safeYear(data.year),
      genres: data.genres && data.genres[0] ? [{ name: data.genres[0] }] : [],
      'artist-credit': toArtistCredit(artist),
      coverUrl: data.images && data.images[0] ? data.images[0].uri : '',
      media: [{ position: 1, tracks: (data.tracklist || []).filter(t => t.type_ !== 'heading').map((song, index) => ({ title: song.title || '', artist: joinSourceNames(song.artists) || artist, position: index + 1, length: 0 })) }]
    };
  }
  if (source === 'spotify') {
    const album = data.album || data;
    const albumArtist = spotifyArtistNames(album.artists);
    const tracks = Array.isArray(data.tracks) ? data.tracks : ((album.tracks && album.tracks.items) || []);
    const discs = new Map();
    for (const song of tracks) {
      const discNo = song.disc_number || 1;
      if (!discs.has(discNo)) discs.set(discNo, []);
      discs.get(discNo).push(song);
    }
    const discNumbers = [...discs.keys()].sort((a, b) => a - b);
    return {
      source: 'Spotify',
      id: `spotify:${album.id || ''}`,
      title: album.name || '',
      date: safeYear(album.release_date),
      genres: album.genres && album.genres[0] ? [{ name: album.genres[0] }] : [],
      'artist-credit': toArtistCredit(albumArtist),
      coverUrl: spotifyImage(album.images, 0),
      media: discNumbers.map((discNo) => {
        const discTracks = (discs.get(discNo) || []).sort((a, b) => (a.track_number || 0) - (b.track_number || 0));
        return {
          position: discNo,
          tracks: discTracks.map((song, index) => ({ title: song.name || '', artist: spotifyArtistNames(song.artists) || albumArtist, position: song.track_number || (index + 1), length: song.duration_ms || 0 }))
        };
      })
    };
  }
  return null;
}

registerIpcHandler('search-metadata-sources', async (event, query, options) => {
  const q = String(query || '').trim();
  if (!q) return [];
  const metadataOptions = normalizeMetadataOptions(options);
  const headers = { 'User-Agent': `${APP_USER_AGENT} ( zafer@example.com )` };
  const jobs = [];
  jobs.push(fetch(`https://musicbrainz.org/ws/2/release/?query=${encodeURIComponent(q)}&fmt=json&limit=10`, { headers }).then(r => r.json()).then(data => (data.releases || []).map(r => normalizeSourceResult('musicbrainz', r.id, r.title, r['artist-credit'] ? r['artist-credit'].map(a => a.name || (a.artist && a.artist.name) || '').join(', ') : '', safeYear(r.date), { label: 'MusicBrainz', thumb: r.id ? `https://coverartarchive.org/release/${encodeURIComponent(r.id)}/front-250` : '' }))).catch(() => []));
  jobs.push(fetch(`https://itunes.apple.com/search?term=${encodeURIComponent(q)}&media=music&entity=album&limit=8`).then(r => r.json()).then(data => (data.results || []).map(r => normalizeSourceResult('itunes', r.collectionId, r.collectionName, r.artistName, safeYear(r.releaseDate), { thumb: r.artworkUrl100 || '', label: 'iTunes' }))).catch(() => []));
  jobs.push(fetch(`https://api.deezer.com/search/album?q=${encodeURIComponent(q)}&limit=8`).then(r => r.json()).then(data => (data.data || []).map(r => normalizeSourceResult('deezer', r.id, r.title, r.artist && r.artist.name, '', { thumb: r.cover_medium || '', label: 'Deezer' }))).catch(() => []));
  const token = String(metadataOptions.discogsToken || '').trim();
  if (token) {
    jobs.push(fetch(`https://api.discogs.com/database/search?type=release&per_page=8&q=${encodeURIComponent(q)}&token=${encodeURIComponent(token)}`, { headers }).then(r => r.json()).then(data => (data.results || []).map(r => {
      const parts = String(r.title || '').split(' - ');
      return normalizeSourceResult('discogs', r.id, parts.length > 1 ? parts.slice(1).join(' - ') : r.title, parts.length > 1 ? parts[0] : '', safeYear(r.year), { thumb: r.thumb || '', label: 'Discogs' });
    })).catch(() => []));
  }
  if (metadataOptions.spotifyClientId && metadataOptions.spotifyClientSecret) {
    jobs.push((async () => {
      const spotifyToken = await getSpotifyAccessToken(metadataOptions.spotifyClientId, metadataOptions.spotifyClientSecret);
      const data = await fetchSpotifyJson(`https://api.spotify.com/v1/search?type=album&limit=8&q=${encodeURIComponent(q)}`, spotifyToken);
      return (((data.albums || {}).items) || []).map(album => normalizeSourceResult('spotify', album.id, album.name, spotifyArtistNames(album.artists), safeYear(album.release_date), { thumb: spotifyImage(album.images, 1), label: 'Spotify' }));
    })().catch(() => []));
  }
  const groups = await Promise.all(jobs);
  return groups.flat().filter(r => r.id);
});

registerIpcHandler('get-metadata-release', async (event, source, id, options) => {
  try {
    source = String(source || '');
    id = String(id || '');
    const metadataOptions = normalizeMetadataOptions(options);
    const headers = { 'User-Agent': `${APP_USER_AGENT} ( zafer@example.com )` };
    if (source === 'musicbrainz') {
      const res = await fetch(`https://musicbrainz.org/ws/2/release/${encodeURIComponent(id)}?inc=recordings+artists&fmt=json`, { headers });
      return normalizeMetadataRelease(source, await res.json());
    }
    if (source === 'itunes') {
      const res = await fetch(`https://itunes.apple.com/lookup?id=${encodeURIComponent(id)}&entity=song&limit=200`);
      const data = await res.json();
      const album = (data.results || []).find(x => x.wrapperType === 'collection') || {};
      const songs = (data.results || []).filter(x => x.wrapperType === 'track').sort((a, b) => (a.discNumber || 1) - (b.discNumber || 1) || (a.trackNumber || 0) - (b.trackNumber || 0));
      return normalizeMetadataRelease(source, { album, songs });
    }
    if (source === 'deezer') {
      const res = await fetch(`https://api.deezer.com/album/${encodeURIComponent(id)}`);
      return normalizeMetadataRelease(source, await res.json());
    }
    if (source === 'discogs') {
      const token = String(metadataOptions.discogsToken || '').trim();
      if (!token) return null;
      const res = await fetch(`https://api.discogs.com/releases/${encodeURIComponent(id)}?token=${encodeURIComponent(token)}`, { headers });
      return normalizeMetadataRelease(source, await res.json());
    }
    if (source === 'spotify') {
      const spotifyToken = await getSpotifyAccessToken(metadataOptions.spotifyClientId, metadataOptions.spotifyClientSecret);
      if (!spotifyToken) return null;
      const album = await fetchSpotifyJson(`https://api.spotify.com/v1/albums/${encodeURIComponent(id)}`, spotifyToken);
      const tracks = album.tracks && Array.isArray(album.tracks.items) ? album.tracks.items.slice() : [];
      let nextUrl = album.tracks && album.tracks.next;
      while (nextUrl) {
        const page = await fetchSpotifyJson(nextUrl, spotifyToken);
        tracks.push(...(page.items || []));
        nextUrl = page.next;
      }
      return normalizeMetadataRelease(source, { album, tracks });
    }
    return null;
  } catch (e) {
    console.error('Metadata release fetch failed:', e);
    return null;
  }
});

registerIpcHandler('lastfm-get-auth-url', async (event, apiKey) => {
  let key = (apiKey || '').trim();
  if (!key) return null;
  try {
    const res = await fetch(`https://ws.audioscrobbler.com/2.0/?method=auth.getToken&api_key=${key}&format=json`);
    const data = await res.json();
    if (data.token) {
      let url = `https://www.last.fm/api/auth/?api_key=${key}&token=${data.token}`;
      shell.openExternal(url);
      return { url, token: data.token };
    }
    return null;
  } catch (e) { return null; }
});

registerIpcHandler('lastfm-get-session', async (event, token, apiKey, sharedSecret) => {
  let key = (apiKey || '').trim();
  let secret = (sharedSecret || '').trim();
  if (!key || !secret || !token) return null;
  try {
    let params = { api_key: key, method: 'auth.getSession', token: token };
    let sig = getLfmSignature(params, secret);
    if (!sig) return null;
    const res = await fetch(`https://ws.audioscrobbler.com/2.0/?method=auth.getSession&api_key=${key}&token=${token}&api_sig=${sig}&format=json`);
    const data = await res.json();
    if (data.session) return { sessionKey: data.session.key, name: data.session.name };
    return null;
  } catch (e) { return null; }
});

registerIpcHandler('lastfm-update-now-playing', async (event, sessionKey, artist, track, apiKey, sharedSecret) => {
  let key = (apiKey || '').trim();
  let secret = (sharedSecret || '').trim();
  if (!key || !secret || !sessionKey) return false;
  try {
    let params = { method: 'track.updateNowPlaying', artist: artist, track: track, api_key: key, sk: sessionKey };
    let sig = getLfmSignature(params, secret);
    if (!sig) return false;
    let body = new URLSearchParams({ ...params, api_sig: sig, format: 'json' });
    const resp = await fetch('https://ws.audioscrobbler.com/2.0/', { method: 'POST', body });
    const data = await resp.json().catch(() => null);
    if (!resp.ok || (data && data.error)) {
      console.log('Last.fm now-playing failed:', data && data.message ? data.message : resp.status);
      return false;
    }
    return true;
  } catch (e) { return false; }
});


registerIpcListener('update-thumbar', (event, isPlaying) => {
  if (process.platform === 'win32' && mainWindow) {
    const { nativeImage } = require('electron');

    function makeIcon(type) {
      const iconPath = path.join(__dirname, 'assets', 'taskbar', `taskbar-${type}.png`);
      if (fs.existsSync(iconPath)) {
        const icon = nativeImage.createFromPath(iconPath);
        if (!icon.isEmpty()) return icon.resize({ width: 24, height: 24, quality: 'best' });
      }
      const paths = {
        prev: '<path d="M11 7L5 12L11 17V7Z" fill="white"/><path d="M19 7L13 12L19 17V7Z" fill="white"/><path d="M4 7V17" stroke="white" stroke-width="2.2" stroke-linecap="round"/>',
        next: '<path d="M13 7L19 12L13 17V7Z" fill="white"/><path d="M5 7L11 12L5 17V7Z" fill="white"/><path d="M20 7V17" stroke="white" stroke-width="2.2" stroke-linecap="round"/>',
        play: '<path d="M8.5 6.8C8.5 6.1 9.25 5.68 9.85 6.04L18.15 11.24C18.72 11.6 18.72 12.4 18.15 12.76L9.85 17.96C9.25 18.32 8.5 17.9 8.5 17.2V6.8Z" fill="white"/>',
        pause: '<rect x="7" y="6" width="3.6" height="12" rx="1.2" fill="white"/><rect x="13.4" y="6" width="3.6" height="12" rx="1.2" fill="white"/>'
      };
      const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24">${paths[type] || paths.play}</svg>`;
      return nativeImage.createFromDataURL('data:image/svg+xml;base64,' + Buffer.from(svg).toString('base64'));
    }

    mainWindow.setThumbarButtons([
      {
        tooltip: 'Previous',
        icon: makeIcon('prev'),
        click() { mainWindow.webContents.send('thumbar-action', 'prev'); }
      },
      {
        tooltip: isPlaying ? 'Pause' : 'Play',
        icon: makeIcon(isPlaying ? 'pause' : 'play'),
        click() { mainWindow.webContents.send('thumbar-action', 'playpause'); }
      },
      {
        tooltip: 'Next',
        icon: makeIcon('next'),
        click() { mainWindow.webContents.send('thumbar-action', 'next'); }
      }
    ]);
  }
});



registerIpcHandler('lastfm-scrobble', async (event, sessionKey, artist, track, timestamp, apiKey, sharedSecret) => {
  let key = (apiKey || '').trim();
  let secret = (sharedSecret || '').trim();
  if (!key || !secret || !sessionKey) return false;
  try {
    let params = { method: 'track.scrobble', 'artist[0]': artist, 'track[0]': track, 'timestamp[0]': timestamp, api_key: key, sk: sessionKey };
    let sig = getLfmSignature(params, secret);
    if (!sig) return false;
    let body = new URLSearchParams({ ...params, api_sig: sig, format: 'json' });
    const resp = await fetch('https://ws.audioscrobbler.com/2.0/', { method: 'POST', body });
    const data = await resp.json().catch(() => null);
    if (!resp.ok || (data && data.error)) {
      console.log('Last.fm scrobble failed:', data && data.message ? data.message : resp.status);
      return false;
    }
    return true;
  } catch (e) { return false; }
});

registerIpcHandler('lastfm-get-recommendations', async (event, sessionKey, apiKey, username) => {
  let key = (apiKey || '').trim();
  if (!key || !username) return [];
  try {
    let recentRes = await fetch(`https://ws.audioscrobbler.com/2.0/?method=user.getRecentTracks&user=${encodeURIComponent(username)}&api_key=${key}&limit=20&format=json`);
    let recentData = await recentRes.json();
    let artistName = "";
    if (recentData.recenttracks && recentData.recenttracks.track && recentData.recenttracks.track.length > 0) {
      let randIdx = Math.floor(Math.random() * recentData.recenttracks.track.length);
      artistName = recentData.recenttracks.track[randIdx].artist['#text'];
    }

    if (!artistName) {
      let topRes = await fetch(`https://ws.audioscrobbler.com/2.0/?method=user.getTopArtists&user=${encodeURIComponent(username)}&api_key=${key}&limit=20&format=json`);
      let topData = await topRes.json();
      if (topData.topartists && topData.topartists.artist && topData.topartists.artist.length > 0) {
        let randIdx = Math.floor(Math.random() * topData.topartists.artist.length);
        artistName = topData.topartists.artist[randIdx].name;
      }
    }

    if (artistName) {
      let simRes = await fetch(`https://ws.audioscrobbler.com/2.0/?method=artist.getSimilar&artist=${encodeURIComponent(artistName)}&api_key=${key}&limit=30&format=json`);
      let simData = await simRes.json();
      if (simData.similarartists && simData.similarartists.artist) {
        let simArtists = simData.similarartists.artist.sort(() => 0.5 - Math.random()).slice(0, 13);
        let fetchPromises = simArtists.map(async (simArtist) => {
          try {
            let topAlbRes = await fetch(`https://ws.audioscrobbler.com/2.0/?method=artist.getTopAlbums&artist=${encodeURIComponent(simArtist.name)}&api_key=${key}&limit=2&format=json`);
            let topAlbData = await topAlbRes.json();
            if (topAlbData.topalbums && topAlbData.topalbums.album && topAlbData.topalbums.album.length > 0) {
              return topAlbData.topalbums.album.slice(0, 2).map(function(alb) {
                return {
                  name: alb.name,
                  artist: simArtist.name,
                  image: (alb.image && alb.image.length > 2) ? alb.image[2]['#text'] : null
                };
              });
            }
          } catch (err) { }
          return [];
        });
        let recsNested = await Promise.all(fetchPromises);
        let recs = [].concat.apply([], recsNested).filter(r => r !== null).sort(() => 0.5 - Math.random());
        return recs;
      }
    }
    return [];
  } catch (e) { return []; }
});

// IPC Handler: Scan Folder for Music
registerIpcHandler('scan-folder', async (event, folderPath, existingLibrary = []) => {
  folderPath = normalizePathInput(folderPath);
  existingLibrary = Array.isArray(existingLibrary) ? existingLibrary : [];
  if (typeof folderPath !== 'string' || !path.isAbsolute(folderPath)) return [];
  if (!isExistingDirectory(folderPath)) {
    const preserved = existingLibrary.filter(item => item && typeof item.filePath === 'string' && isPathWithin(item.filePath, folderPath));
    return finishFolderScan(event, preserved, [{ path: folderPath, error: 'Folder is missing or inaccessible' }], 0);
  }
  const supportedExtensions = AUDIO_EXTENSIONS;
  const rawFiles = [];
  const failures = [];
  try {
    await walkDir(folderPath, supportedExtensions, rawFiles, failures);
  } catch (e) {
    console.error("Error walking directory", e);
    failures.push({ path: folderPath, error: e.message || String(e) });
    if (e && e.code === 'AUDIO_SCAN_LIMIT') {
      const preserved = existingLibrary.filter(item => item && typeof item.filePath === 'string' && isPathWithin(item.filePath, folderPath));
      return finishFolderScan(event, preserved, failures, rawFiles.length);
    }
  }

  const existingMap = new Map();
  existingLibrary.forEach((item) => {
    if (item && typeof item.filePath === 'string') existingMap.set(item.filePath, item);
  });

  const musicFiles = new Array(rawFiles.length);
  const totalFiles = rawFiles.length;
  const scanStartedAt = Date.now();
  let nextIndex = 0;
  let completed = 0;

  sendScanProgress(event, { current: 0, total: totalFiles });

  async function scanWorker() {
    while (true) {
      const i = nextIndex++;
      if (i >= totalFiles) return;
      const filePath = rawFiles[i];
      try {
        const fileStat = await fs.promises.stat(filePath);
        const existingItem = existingMap.get(filePath);
        if (existingItem && existingItem.fileSize === fileStat.size && existingItem.modifiedAtMs === fileStat.mtimeMs) {
          musicFiles[i] = existingItem;
        } else {
          musicFiles[i] = await buildLibraryItemFromAudioFile(filePath, fileStat);
          // A re-parse of a known file (tags changed) is not a new addition — keep its original date
          if (musicFiles[i] && existingItem && existingItem.addedAtMs !== null && existingItem.addedAtMs !== undefined) {
            musicFiles[i].addedAtMs = existingItem.addedAtMs;
          } else if (musicFiles[i] && existingItem) {
            musicFiles[i].addedAtMs = null;
          } else if (musicFiles[i] && !existingItem) {
            musicFiles[i].addedAtMs = scanStartedAt;
          }
        }
      } catch (e) {
        const existingItem = existingMap.get(filePath);
        if (existingItem) musicFiles[i] = existingItem;
        if (failures.length < 100) failures.push({ path: filePath, error: e && (e.code || e.message) ? (e.code || e.message) : String(e) });
      }

      completed++;
      if (completed % 25 === 0 || completed === totalFiles) {
        sendScanProgress(event, { current: completed, total: totalFiles });
        await new Promise((resolve) => setImmediate(resolve));
      }
    }
  }

  const concurrency = Math.min(4, Math.max(1, totalFiles));
  await Promise.all(Array.from({ length: concurrency }, () => scanWorker()));

  sendScanProgress(event, { current: totalFiles, total: totalFiles });
  const scanned = musicFiles.filter(Boolean);
  if (failures.length) {
    const byPath = new Map(scanned.map(item => [item.filePath, item]));
    for (const existingItem of existingLibrary) {
      if (!existingItem || typeof existingItem.filePath !== 'string' || byPath.has(existingItem.filePath)) continue;
      if (failures.some(failure => isPathWithin(existingItem.filePath, failure.path))) byPath.set(existingItem.filePath, existingItem);
    }
    return finishFolderScan(event, Array.from(byPath.values()), failures, totalFiles);
  }
  return finishFolderScan(event, scanned, [], totalFiles);
});

// IPC Handler: Read and Parse CSV
registerIpcHandler('parse-csv', async (event, csvPath) => {
  csvPath = normalizePathInput(csvPath);
  if (!isExistingFileWithExt(csvPath, ['.csv'])) return [];
  const stat = await fs.promises.stat(csvPath);
  if (!stat.isFile() || stat.size > MAX_CSV_BYTES) throw new Error('CSV file is larger than the 64 MB import limit');
  return new Promise((resolve, reject) => {
    const results = [];
    const input = fs.createReadStream(csvPath);
    const parser = parse({ columns: true, skip_empty_lines: true, max_record_size: 1024 * 1024 });
    let settled = false;
    const fail = (err) => {
      if (settled) return;
      settled = true;
      input.destroy();
      reject(err);
    };
    input.on('error', fail);
    input.pipe(parser)
      .on('data', (data) => {
        if (results.length >= MAX_CSV_RECORDS) {
          parser.destroy(new Error(`CSV contains more than ${MAX_CSV_RECORDS} records`));
          return;
        }
        results.push(data);
      })
      .on('end', () => {
        if (settled) return;
        settled = true;
        resolve(results);
      })
      .on('error', fail);
  });
});

// Play audio file
registerIpcHandler('get-audio-file', async (event, filePath) => {
  filePath = normalizePathInput(filePath);
  if (!isExistingFileWithExt(filePath, AUDIO_EXTENSIONS)) return null;
  let handle = null;
  try {
    handle = await fs.promises.open(filePath, 'r');
    const stat = await handle.stat();
    if (!stat.isFile() || stat.size > MAX_AUDIO_IPC_BYTES) {
      const error = new Error('Audio file exceeds the 128 MB in-memory analysis limit');
      error.code = 'AUDIO_IPC_LIMIT';
      throw error;
    }
    const buffer = await handle.readFile();
    return buffer; // Returns as Uint8Array to renderer
  } catch (e) {
    if (e && e.code === 'AUDIO_IPC_LIMIT') throw e;
    console.error(e);
    return null;
  } finally {
    if (handle) await handle.close().catch(() => { });
  }
});

// Export CSV
registerIpcHandler('export-csv', async (event, playlists) => {
  const { canceled, filePath } = await dialog.showSaveDialog(mainWindow, {
    filters: [{ name: 'CSV', extensions: ['csv'] }],
    defaultPath: 'playlists_export.csv'
  });

  if (canceled || !filePath) return false;

  const escapeCSV = (str) => {
    if (str === null || str === undefined) return '';
    const s = String(str);
    if (s.includes(',') || s.includes('"') || s.includes('\n')) {
      return `"${s.replace(/"/g, '""')}"`;
    }
    return s;
  };

  // Normalize a track object into standard fields regardless of source format
  const normTrack = (track) => {
    const mf = track.matchedFile || {};
    // Library tracks: {matchedFile:{title,artist,album,duration,...}, title, artist, album, duration}
    // CSV-imported tracks: {Song, Artist, Album, Duration, BPM, ...} (external tools)
    // Drag-drop added: {Song, Artist, Album}
    const title = track.title || mf.title || track.Song || track.song || track.Name || track.name || track.TITLE || '';
    const artist = track.artist || mf.artist || track.Artist || track.ARTIST || '';
    const album = track.album || mf.album || track.Album || track.ALBUM || '';
    const duration = track.duration || mf.duration || track.Duration || track.DURATION || 0;
    const genre = track.genre || mf.genre || track.Genres || track.Genre || track.GENRE || '';
    const filePath = track.filePath || mf.filePath || track.FilePath || track.FILEPATH || track.Path || track.path || '';
    return { title, artist, album, duration, genre, filePath };
  };

  let csvContent = 'Playlist,Song,Artist,Album,Duration,Genre,FilePath\n';

  playlists.forEach(pl => {
    if (!pl.tracks) return;
    pl.tracks.forEach(track => {
      const t = normTrack(track);
      csvContent += `${escapeCSV(pl.name)},${escapeCSV(t.title)},${escapeCSV(t.artist)},${escapeCSV(t.album)},${escapeCSV(t.duration)},${escapeCSV(t.genre)},${escapeCSV(t.filePath)}\n`;
    });
  });

  await fs.promises.writeFile(filePath, csvContent, 'utf8');
  return true;
});

// IPC: Scan folder for image files (for album cover slideshow)
registerIpcHandler('scan-folder-images', async (event, folderPath) => {
  folderPath = normalizePathInput(folderPath);
  if (!isExistingDirectory(folderPath)) return [];
  const imgExts = IMAGE_EXTENSIONS;
  try {
    const files = await fs.promises.readdir(folderPath);
    return files
      .filter(f => imgExts.includes(path.extname(f).toLowerCase()))
      .map(f => getSafeFileUrl(path.join(folderPath, f)));
  } catch (e) { return []; }
});

// IPC: Register / unregister global shortcuts dynamically
registerIpcHandler('register-shortcuts', (event, shortcuts) => {
  return applyGlobalShortcuts(shortcuts);
});

// IPC: Open LRC file dialog
registerIpcHandler('dialog:openLrc', async () => {
  const { canceled, filePaths } = await dialog.showOpenDialog(mainWindow, {
    properties: ['openFile'],
    filters: [{ name: 'LRC Lyrics', extensions: ['lrc', 'txt'] }]
  });
  if (canceled) return null;
  try {
    return fs.readFileSync(filePaths[0], 'utf8');
  } catch (e) { return null; }
});
